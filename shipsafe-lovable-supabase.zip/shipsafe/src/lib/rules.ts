import { SB_RULES } from "./rules-supabase";
export type Sev = "critical" | "high" | "medium";
export type Finding = { id: string; sev: Sev; path: string; line: number; ev?: string };
type T3 = { en: string; te?: string; hi?: string };
export type Rule = { id: string; sev: Sev; title: T3; why: string; fix: string; test: (path: string, text: string) => number[] };
const L = (t: string, re: RegExp) => t.split("\n").flatMap((s, i) => (re.test(s) ? [i + 1] : []));
const CODE = /\.(t|j)sx?$|\.(mjs|cjs|vue|svelte)$/;
const code = (re: RegExp) => (p: string, t: string) => (CODE.test(p) ? L(t, re) : []);
const none = () => [] as number[];
export const RULES: Rule[] = [
  { id: "env-file", sev: "critical", title: { en: "A secrets file is in your repo", te: "మీ రిపోలో సీక్రెట్స్ ఫైల్ ఉంది", hi: "आपके रिपो में सीक्रेट्स फाइल है" },
    why: "Files like .env hold passwords and API keys. Anyone who can see the repo can copy them.",
    fix: "My repo has a committed .env file. Remove it from git, add .env* to .gitignore, keep a .env.example with empty values, and explain how to rotate every key that was inside it.",
    test: p => (/(^|\/)\.env(\.[\w-]+)?$/.test(p) && !/\.(example|sample|template)$/.test(p) ? [1] : []) },
  { id: "secret", sev: "critical", title: { en: "A secret key is written in the code", te: "కోడ్‌లోనే సీక్రెట్ కీ ఉంది", hi: "कोड में ही सीक्रेट की लिखी है" },
    why: "Keys typed straight into code become public if the repo is public. Attackers scan GitHub for them all day.",
    fix: "Find every API key or token written directly in my code. Move each into an environment variable that is read on the server only, and tell me which keys I must rotate.",
    test: (_p, t) => L(t, /AKIA[0-9A-Z]{16}|sk_live_[0-9a-zA-Z]{16,}|sk-(proj-)?[A-Za-z0-9_-]{32,}|gh[pousr]_[A-Za-z0-9]{36}|AIza[0-9A-Za-z_-]{35}|-----BEGIN (RSA |EC )?PRIVATE KEY-----/) },
  { id: "public-secret", sev: "critical", title: { en: "A secret is sent to every visitor’s browser", te: "సీక్రెట్ బ్రౌజర్‌కు పబ్లిక్‌గా వెళ్తోంది", hi: "सीक्रेट हर विज़िटर के ब्राउज़र को भेजा जा रहा है" },
    why: "Variables starting with NEXT_PUBLIC_, VITE_ or REACT_APP_ are shipped to the browser. A secret or service-role key there is visible to everyone.",
    fix: "A secret or service-role key is exposed through a public environment variable. Move it to a server-only variable, call it from an API route or server action, and tell me to rotate the exposed key.",
    test: (_p, t) => L(t, /(NEXT_PUBLIC|VITE|REACT_APP|EXPO_PUBLIC)_\w*(SECRET|PRIVATE|SERVICE_ROLE)/i) },
  { id: "eval", sev: "high", title: { en: "Dangerous use of eval", te: "ప్రమాదకరమైన eval ఉపయోగం", hi: "खतरनाक eval का उपयोग" },
    why: "eval and new Function run text as code. If a user can influence that text, they can run their own code on your app.",
    fix: "Replace eval or new Function in this code with a safe alternative such as JSON.parse or a lookup table, and never run text from users as code.", test: code(/\beval\(|new Function\(/) },
  { id: "sql-concat", sev: "high", title: { en: "User input is joined into a SQL query", te: "SQL ప్రశ్నలో యూజర్ ఇన్‌పుట్ కలుస్తోంది", hi: "SQL क्वेरी में यूज़र इनपुट जुड़ रहा है" },
    why: "Building a query by joining strings lets an attacker change what the query does and read or delete your data.",
    fix: "Rewrite this database query to use parameterized queries or the ORM’s safe methods instead of joining strings.", test: code(/\b(query|execute|raw|\$queryRawUnsafe)\w*\(\s*(`[^`]*\$\{|["'][^"']*["']\s*\+)/i) },
  { id: "xss", sev: "medium", title: { en: "User content may be inserted straight into the page", te: "యూజర్ కంటెంట్ నేరుగా పేజీలో చేరుతోంది", hi: "यूज़र कंटेंट सीधे पेज में डाला जा रहा है" },
    why: "dangerouslySetInnerHTML and innerHTML insert raw HTML. If it includes user text, attackers can run scripts in other people’s browsers.",
    fix: "Stop inserting raw HTML here. Render text normally, or sanitize the HTML with a library like DOMPurify first.", test: code(/dangerouslySetInnerHTML|\.innerHTML\s*=/) },
  { id: "cors", sev: "medium", title: { en: "Any website can call your API", te: "ఏ వెబ్‌సైట్ అయినా మీ API ని పిలవవచ్చు", hi: "कोई भी वेबसाइट आपकी API को कॉल कर सकती है" },
    why: "A wildcard CORS setting lets other websites make requests to your API from your users’ browsers.",
    fix: "Change the CORS setting from * to a list of only my own website addresses.", test: code(/Access-Control-Allow-Origin["']?\s*[:,]\s*["']\*|origin:\s*["']\*["']/i) },
  { id: "tls-off", sev: "high", title: { en: "Secure connection checks are turned off", te: "సురక్షిత కనెక్షన్ తనిఖీ ఆపివేయబడింది", hi: "सुरक्षित कनेक्शन की जाँच बंद है" },
    why: "Turning off certificate checks lets someone on the network pretend to be the server and read or change the data.",
    fix: "Remove rejectUnauthorized: false or NODE_TLS_REJECT_UNAUTHORIZED=0 and fix the certificate problem properly.", test: code(/rejectUnauthorized:\s*false|NODE_TLS_REJECT_UNAUTHORIZED\s*=\s*["']?0/) },
  { id: "no-auth", sev: "medium", title: { en: "This API route may not check who is logged in", te: "ఈ API కి లాగిన్ తనిఖీ లేకపోవచ్చు", hi: "इस API में लॉगिन जाँच नहीं हो सकती" },
    why: "Routes that change data should confirm the user is signed in. This one writes data but shows no sign of a login check. It may be a false alarm.",
    fix: "Add an authentication check at the top of this API route so only signed-in users can use it, and return 401 otherwise. Also check the user owns the data they change.",
    test: (p, t) => (/(^|\/)api\//.test(p) && CODE.test(p) && /export\s+(async\s+)?(function\s+)?(POST|PUT|PATCH|DELETE)|req\.method/.test(t) && !/getServerSession|auth\(|getUser|currentUser|session|jwt|verify|authorization|cookies\(|clerk|supabase\.auth/i.test(t) ? [1] : []) },
  { id: "dep", sev: "high", title: { en: "A package you use has known security problems", te: "మీరు వాడే ప్యాకేజీలో తెలిసిన భద్రతా సమస్యలు ఉన్నాయి", hi: "आपके पैकेज में ज्ञात सुरक्षा समस्याएँ हैं" },
    why: "Public databases list security flaws in this version of the package. Attackers use these lists.",
    fix: "Run npm audit, update the vulnerable packages listed, and test that the app still works.", test: none },
  { id: "no-https", sev: "high", title: { en: "Your website doesn’t answer over HTTPS" }, why: "Without HTTPS, anyone on the network can read or change what your visitors send.", fix: "Turn on HTTPS for this domain and redirect all HTTP traffic to it.", test: none },
  { id: "hdr-hsts", sev: "medium", title: { en: "Missing HSTS header" }, why: "HSTS tells browsers to always use HTTPS for your site.", fix: "Add the Strict-Transport-Security header to all responses.", test: none },
  { id: "hdr-csp", sev: "medium", title: { en: "Missing Content-Security-Policy header" }, why: "A CSP limits which scripts can run on your pages, which reduces the damage of injected code.", fix: "Add a Content-Security-Policy header that allows only the scripts and sources your app needs.", test: none },
  { id: "hdr-xcto", sev: "medium", title: { en: "Missing X-Content-Type-Options header" }, why: "It stops browsers from guessing file types, which can be abused to run uploaded files as scripts.", fix: "Add the header X-Content-Type-Options: nosniff to all responses.", test: none },
  { id: "exposed-env", sev: "critical", title: { en: "Your .env file is downloadable from the website" }, why: "Anyone can open this address and read your passwords and keys.", fix: "Stop serving .env from the public web folder immediately, then rotate every key that was in it.", test: none },
  { id: "exposed-git", sev: "critical", title: { en: "Your .git folder is downloadable from the website" }, why: "Attackers can rebuild your source code and history, including old secrets, from it.", fix: "Block public access to the .git folder and remove it from the deployed files.", test: none },
  ...SB_RULES,
];
// Adds the plain-language title, explanation and fix prompt to a stored finding.
export const describe = (f: Finding, lang: keyof T3 = "en") => {
  const r = RULES.find(x => x.id === f.id);
  return { ...f, title: r?.title[lang] ?? r?.title.en ?? f.id, why: r?.why ?? "", fix: r?.fix ?? "" };
};
export const scoreOf = (f: Finding[]) => {
  const c: Record<string, number> = {}, w = { critical: 25, high: 10, medium: 4 };
  let pen = 0;
  f.forEach(x => { c[x.id] = (c[x.id] ?? 0) + 1; if (c[x.id] <= 3) pen += w[x.sev]; });
  return Math.max(0, 100 - pen);
};
// Checks package.json versions against the free OSV.dev database. Uses the version written in package.json, so it is approximate.
export async function depFindings(files: Map<string, string>): Promise<Finding[]> {
  const q: any[] = [], meta: { path: string; name: string; v: string }[] = [], out: Finding[] = [];
  for (const [p, t] of files) {
    if (!/(^|\/)package\.json$/.test(p)) continue;
    let j: any; try { j = JSON.parse(t); } catch { continue; }
    for (const [n, r] of Object.entries({ ...j.dependencies, ...j.devDependencies }) as [string, string][]) {
      const v = String(r).replace(/^[\^~>=<\s]+/, "");
      if (/^\d+\.\d+\.\d+$/.test(v)) { q.push({ package: { name: n, ecosystem: "npm" }, version: v }); meta.push({ path: p, name: n, v }); }
    }
  }
  for (let i = 0; i < q.length && i < 1000; i += 500) {
    const r = await fetch("https://api.osv.dev/v1/querybatch", { method: "POST", body: JSON.stringify({ queries: q.slice(i, i + 500) }) }).then(x => x.json()).catch(() => null);
    r?.results?.forEach((x: any, k: number) => { if (x.vulns?.length) { const m = meta[i + k]; out.push({ id: "dep", sev: "high", path: m.path, line: 1, ev: `${m.name}@${m.v}` }); } });
  }
  return out;
}
