import dns from "dns/promises";
import { db } from "./db";
import { parseRepo, tokenFor, fetchFiles } from "./github";
import { RULES, depFindings, scoreOf, Finding } from "./rules";
import { supabaseFindings, detectStack } from "./supabase";
import { bundleChecks } from "./live-supabase";
export async function runScan(id: string) {
  const s = await db.scan.findUniqueOrThrow({ where: { id } });
  await db.scan.update({ where: { id }, data: { status: "running" } });
  try {
    const r = parseRepo(s.repoUrl)!;
    const proj = s.userId ? await db.project.findFirst({ where: { userId: s.userId, owner: { equals: r.owner, mode: "insensitive" }, repo: { equals: r.repo, mode: "insensitive" } } }) : null;
    const { files, isPrivate, incomplete } = await fetchFiles(r.owner, r.repo, await tokenFor(proj?.installationId));
    const f: Finding[] = [];
    for (const [p, t] of files) for (const rule of RULES) for (const line of rule.test(p, t).slice(0, 5)) f.push({ id: rule.id, sev: rule.sev, path: p, line });
    f.push(...(await depFindings(files)));
    f.push(...supabaseFindings(files, !incomplete));
    const o = { critical: 0, high: 1, medium: 2 };
    f.sort((a, b) => o[a.sev] - o[b.sev]);
    await db.scan.update({ where: { id }, data: { status: "done", findings: f.slice(0, 300) as any, score: scoreOf(f), isPrivate, stack: detectStack(files) } });
    // If the owner already proved they own a domain, check the live site on every scan (including re-scans after a push).
    if (proj?.domain && proj.domainVerified) {
      const lf = await liveChecks(proj.domain).catch(() => null);
      if (lf) await db.project.update({ where: { id: proj.id }, data: { liveFindings: lf as any, liveCheckedAt: new Date() } });
    }
  } catch (e: any) {
    await db.scan.update({ where: { id }, data: { status: "failed", error: String(e.message).slice(0, 200) } });
  }
}
// Live checks only run on domains the user has proven they own, and never on private network addresses.
const PRIVATE = /^(10\.|127\.|169\.254\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|0\.|::1$|f[cd]|fe80)/i;
export async function publicHost(h: string) {
  if (!/^[a-z0-9.-]+\.[a-z]{2,}$/i.test(h)) return false;
  try { const a = await dns.lookup(h, { all: true }); return a.length > 0 && !a.some(x => PRIVATE.test(x.address)); } catch { return false; }
}
export async function verifyDomain(domain: string, token: string) {
  if (!(await publicHost(domain))) return false;
  try { const t = await dns.resolveTxt("_shipsafe." + domain); if (t.flat().includes("shipsafe=" + token)) return true; } catch {}
  try {
    const r = await fetch(`https://${domain}/.well-known/shipsafe.txt`, { redirect: "manual", signal: AbortSignal.timeout(8000) });
    return r.ok && (await r.text()).trim() === token;
  } catch { return false; }
}
export async function liveChecks(domain: string) {
  const out: Finding[] = [];
  if (!(await publicHost(domain))) return out; // re-check: DNS may have changed since the domain was verified
  const base = `https://${domain}`, opt = { redirect: "manual" as const, signal: AbortSignal.timeout(8000) };
  try {
    const h = (await fetch(base, opt)).headers;
    if (!h.get("strict-transport-security")) out.push({ id: "hdr-hsts", sev: "medium", path: domain, line: 0 });
    if (!h.get("content-security-policy")) out.push({ id: "hdr-csp", sev: "medium", path: domain, line: 0 });
    if (h.get("x-content-type-options")?.toLowerCase() !== "nosniff") out.push({ id: "hdr-xcto", sev: "medium", path: domain, line: 0 });
  } catch { out.push({ id: "no-https", sev: "high", path: domain, line: 0 }); return out; }
  out.push(...(await bundleChecks(domain).catch(() => [])));
  for (const [path, id, re] of [["/.env", "exposed-env", /^[A-Z][A-Z0-9_]*=/m], ["/.git/config", "exposed-git", /\[core\]/]] as const) {
    try { const r = await fetch(base + path, opt); if (r.status === 200 && re.test((await r.text()).slice(0, 5000))) out.push({ id, sev: "critical", path, line: 0 }); } catch {}
  }
  return out;
}
