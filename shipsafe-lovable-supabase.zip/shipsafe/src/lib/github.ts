import jwt from "jsonwebtoken";
const H = (t?: string) => ({ Accept: "application/vnd.github+json", "User-Agent": "shipsafe", ...(t ? { Authorization: `Bearer ${t}` } : {}) });
export const parseRepo = (u: string) => {
  const m = u.trim().match(/^(?:https?:\/\/)?github\.com\/([\w.-]+)\/([\w.-]+?)(?:\.git)?\/?$/i);
  return m ? { owner: m[1], repo: m[2] } : null;
};
async function appToken(installationId: string) {
  const now = Math.floor(Date.now() / 1000);
  const app = jwt.sign({ iat: now - 60, exp: now + 540, iss: process.env.GH_APP_ID }, process.env.GH_APP_KEY!.replace(/\\n/g, "\n"), { algorithm: "RS256" });
  const r = await fetch(`https://api.github.com/app/installations/${installationId}/access_tokens`, { method: "POST", headers: H(app) }).then(x => x.json());
  return r.token as string;
}
export const tokenFor = async (installationId?: string | null) => (installationId && process.env.GH_APP_ID ? appToken(installationId) : process.env.GITHUB_TOKEN || undefined);
const SKIP = /(^|\/)(node_modules|dist|build|\.next|vendor|\.git)\/|package-lock\.json|yarn\.lock|pnpm-lock|\.min\.|\.(png|jpe?g|gif|svg|ico|woff2?|ttf|pdf|zip|mp4|lock)$/i;
export async function fetchFiles(owner: string, repo: string, token?: string) {
  const api = `https://api.github.com/repos/${owner}/${repo}`;
  const info = await fetch(api, { headers: H(token) });
  if (!info.ok) throw new Error(info.status === 404 ? "Repository not found, or it is private." : "GitHub returned an error (" + info.status + "). Try again later.");
  const { default_branch: br, private: priv } = await info.json();
  const tree = await fetch(`${api}/git/trees/${br}?recursive=1`, { headers: H(token) }).then(x => x.json());
  const blobs = (tree.tree ?? []).filter((f: any) => f.type === "blob" && !SKIP.test(f.path));
  const small = blobs.filter((f: any) => f.size < 100000);
  // Read Supabase files, package.json, env files and API routes first so a big front end can’t push them out of the 150-file limit.
  const PRIO = /^(supabase\/|package\.json$|\.env)|(^|\/)api\//i;
  const picks = [...small.filter((f: any) => PRIO.test(f.path)), ...small.filter((f: any) => !PRIO.test(f.path))].slice(0, 150);
  const files = new Map<string, string>();
  for (let i = 0; i < picks.length; i += 10)
    await Promise.all(picks.slice(i, i + 10).map(async (f: any) => {
      const url = token ? `${api}/contents/${encodeURI(f.path)}?ref=${br}` : `https://raw.githubusercontent.com/${owner}/${repo}/${br}/${encodeURI(f.path)}`;
      const r = await fetch(url, { headers: token ? { ...H(token), Accept: "application/vnd.github.raw+json" } : {} }).catch(() => null);
      if (r?.ok) files.set(f.path, await r.text());
    }));
  // If any SQL file was skipped (too big, over the limit, or failed to download) we can’t claim a table lacks row-level security.
  const incomplete = !!tree.truncated || blobs.some((f: any) => /\.sql$/i.test(f.path) && !files.has(f.path));
  return { files, isPrivate: !!priv, incomplete };
}
// Opens a pull request that adds .env files to .gitignore. Needs the app to have Contents and Pull requests write access.
export async function fixGitignorePr(owner: string, repo: string, token: string) {
  const api = `https://api.github.com/repos/${owner}/${repo}`;
  const j = (u: string, o?: RequestInit) => fetch(u, { ...o, headers: { ...H(token), "content-type": "application/json" } }).then(r => r.json());
  const { default_branch: br } = await j(api);
  const ref = await j(`${api}/git/ref/heads/${br}`);
  const name = `shipsafe/ignore-env-${Date.now()}`;
  await j(`${api}/git/refs`, { method: "POST", body: JSON.stringify({ ref: `refs/heads/${name}`, sha: ref.object.sha }) });
  const cur = await fetch(`${api}/contents/.gitignore?ref=${br}`, { headers: H(token) }).then(r => (r.ok ? r.json() : null));
  const old = cur ? Buffer.from(cur.content, "base64").toString() : "";
  const next = (old && !old.endsWith("\n") ? old + "\n" : old) + ".env\n.env.*\n!.env.example\n";
  await j(`${api}/contents/.gitignore`, { method: "PUT", body: JSON.stringify({ message: "Ignore .env files (ShipSafe)", content: Buffer.from(next).toString("base64"), branch: name, ...(cur ? { sha: cur.sha } : {}) }) });
  const pr = await j(`${api}/pulls`, { method: "POST", body: JSON.stringify({ title: "Stop tracking .env files", head: name, base: br, body: "Adds .env files to .gitignore. This does not remove secrets already in git history: rotate any keys that were committed." }) });
  if (!pr.html_url) throw new Error("GitHub refused the pull request. Check the app’s write permissions.");
  return pr.html_url as string;
}
