import { sha } from "./db";
// Same formula the scan endpoint uses to remember an anonymous visitor without storing their IP address.
export const ipHashOf = (req: Request) => sha((req.headers.get("x-forwarded-for") ?? "local").split(",")[0] + (process.env.IP_SALT ?? ""));
