import { PrismaClient } from "@prisma/client";
import { createHash } from "crypto";
const g = globalThis as any;
export const db: PrismaClient = g.p ?? (g.p = new PrismaClient());
export const sha = (s: string) => createHash("sha256").update(s).digest("hex");
