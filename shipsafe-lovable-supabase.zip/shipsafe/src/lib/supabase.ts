// Repo-wide checks for Supabase projects (migrations, config and client code).
import type { Finding } from "./rules";
const CODE = /\.(t|j)sx?$|\.(mjs|cjs|vue|svelte)$/;
// Replace SQL comments with spaces so line numbers stay correct and commented-out SQL is ignored.
const blank = (s: string) => s.replace(/--[^\n]*|\/\*[\s\S]*?\*\//g, m => m.replace(/[^\n]/g, " "));
const lineAt = (s: string, i: number) => s.slice(0, i).split("\n").length;
const REF = String.raw`((?:"?\w+"?\s*\.\s*)?"?\w+"?)`;
// Returns the table name for objects in the public schema, null for other schemas (auth, storage, ...).
function tbl(ref: string): string | null {
  const p = ref.replace(/"/g, "").split(".").map(x => x.trim().toLowerCase());
  return p.length === 2 && p[0] !== "public" ? null : p[p.length - 1];
}
const pkgDeps = (files: Map<string, string>) => {
  const all: Record<string, string>[] = [];
  for (const [p, t] of files) if (/(^|\/)package\.json$/.test(p)) { try { const j = JSON.parse(t); all.push({ ...j.dependencies, ...j.devDependencies }); } catch {} }
  return all;
};
export function detectStack(files: Map<string, string>) {
  const d = pkgDeps(files), has = (n: string) => d.some(x => n in x), tags: string[] = [];
  if (has("lovable-tagger")) tags.push("lovable");
  if (has("@supabase/supabase-js") || [...files.keys()].some(p => /(^|\/)supabase\//.test(p))) tags.push("supabase");
  if (has("next")) tags.push("next"); else if (has("vite")) tags.push("vite");
  return tags.join(",");
}
type Ev = { i: number; k: "create" | "enable" | "disable" | "drop"; t: string };
// `complete` must be false when some .sql files could not be read: without every migration we can’t say a table lacks RLS.
export function supabaseFindings(files: Map<string, string>, complete = true): Finding[] {
  const out: Finding[] = [], created = new Map<string, { path: string; line: number }>(), enabled = new Set<string>();
  const sql = [...files].filter(([p]) => /\.sql$/i.test(p)).sort(([a], [b]) => (a < b ? -1 : 1));
  for (const [path, raw] of sql) {
    const t = blank(raw), ev: Ev[] = [];
    const add = (re: RegExp, k: Ev["k"]) => { for (const m of t.matchAll(re)) { const n = tbl(m[1]); if (n) ev.push({ i: m.index!, k, t: n }); } };
    add(new RegExp(String.raw`create\s+(?:unlogged\s+)?table\s+(?:if\s+not\s+exists\s+)?${REF}`, "gi"), "create");
    add(new RegExp(String.raw`alter\s+table\s+(?:if\s+exists\s+)?(?:only\s+)?${REF}\s+enable\s+row\s+level\s+security`, "gi"), "enable");
    add(new RegExp(String.raw`alter\s+table\s+(?:if\s+exists\s+)?(?:only\s+)?${REF}\s+disable\s+row\s+level\s+security`, "gi"), "disable");
    add(new RegExp(String.raw`drop\s+table\s+(?:if\s+exists\s+)?${REF}`, "gi"), "drop");
    ev.sort((a, b) => a.i - b.i).forEach(e => {
      if (e.k === "create") { if (!created.has(e.t)) created.set(e.t, { path, line: lineAt(t, e.i) }); }
      else if (e.k === "enable") enabled.add(e.t);
      else if (e.k === "disable") enabled.delete(e.t);
      else { created.delete(e.t); enabled.delete(e.t); }
    });
    // Policies
    for (const m of t.matchAll(new RegExp(String.raw`create\s+policy\s+("[^"]+"|\w+)\s+on\s+${REF}([\s\S]*?);`, "gi"))) {
      const name = m[1].replace(/"/g, ""), table = tbl(m[2]);
      if (!table) continue; // policies on storage.objects etc. are not judged
      const body = m[3], head = body.split(/\b(?:using|with\s+check)\b/i)[0], exprs = body.slice(head.length);
      const cmd = (head.match(/\bfor\s+(select|insert|update|delete|all)\b/i)?.[1] ?? "all").toLowerCase(), write = cmd !== "select";
      const roles = (head.match(/\bto\s+([\s\S]+)$/i)?.[1] ?? "public").split(",").map(r => r.replace(/["\s]/g, "").toLowerCase()).filter(Boolean);
      const where = { path, line: lineAt(t, m.index!), ev: `${table}: ${name}` };
      if (roles.every(r => ["service_role", "postgres", "supabase_auth_admin"].includes(r))) continue;
      const everyone = roles.some(r => r === "public" || r === "anon");
      if (/user_metadata|raw_user_meta_data/i.test(exprs)) { out.push({ id: "sb-policy-metadata", sev: "high", ...where }); continue; }
      if (/\b(?:using|with\s+check)\s*\(\s*(?:true|1\s*=\s*1)\s*\)/i.test(exprs)) {
        if (everyone) out.push({ id: "sb-policy-open", sev: write ? "critical" : "medium", ...where });
        else if (write) out.push({ id: "sb-policy-open", sev: "high", ...where });
        continue;
      }
      const onlyLoggedIn = /auth\.role\(\)\s*=\s*'authenticated'|auth\.uid\(\)\s+is\s+not\s+null/i.test(exprs);
      const checksUser = /=\s*\(?\s*(?:select\s+)?auth\.uid\(\)|auth\.uid\(\)\s*\)?\s*=|has_role|is_admin|is_member/i.test(exprs);
      if (onlyLoggedIn && !checksUser) out.push({ id: "sb-policy-any-user", sev: write ? "high" : "medium", ...where });
    }
    // SECURITY DEFINER functions without a fixed search_path
    const low = t.toLowerCase();
    for (const m of t.matchAll(/security\s+definer/gi)) {
      // The function’s header runs from CREATE to the start of its body, so a later function’s search_path can’t count.
      const start = low.lastIndexOf("create", m.index!), end = t.slice(m.index!).search(/\bas\s+(\$|')|\$\$|;/i);
      const header = t.slice(start < 0 ? 0 : start, m.index! + (end < 0 ? 200 : end));
      if (!/search_path/i.test(header)) out.push({ id: "sb-definer", sev: "medium", path, line: lineAt(t, m.index!), ev: header.match(/function\s+([\w."]+)/i)?.[1]?.replace(/"/g, "") });
    }
    // Views that bypass RLS
    for (const m of t.matchAll(new RegExp(String.raw`create\s+(?:or\s+replace\s+)?view\s+${REF}([\s\S]*?);`, "gi"))) {
      const v = tbl(m[1]); if (!v || /security_invoker\s*=\s*(true|on|1)/i.test(m[2].slice(0, 200))) continue;
      out.push({ id: "sb-view", sev: "medium", path, line: lineAt(t, m.index!), ev: v });
    }
    // Public storage buckets
    for (const m of t.matchAll(/insert\s+into\s+storage\.buckets\s*\(([^)]*)\)\s*values\s*\(([^)]*)\)/gi)) {
      const cols = m[1].split(",").map(c => c.trim().toLowerCase()), vals = m[2].split(",").map(v => v.trim().toLowerCase()), pi = cols.indexOf("public");
      if (pi >= 0 && vals[pi] === "true") out.push({ id: "sb-bucket-public", sev: "medium", path, line: lineAt(t, m.index!), ev: vals[cols.indexOf("name") >= 0 ? cols.indexOf("name") : 0]?.replace(/'/g, "") });
    }
  }
  if (complete) for (const [t, w] of created) if (!enabled.has(t)) out.push({ id: "sb-no-rls", sev: "critical", path: w.path, line: w.line, ev: t });
  // Service role key used where visitors can read the code
  const d = pkgDeps(files), isVite = d.some(x => "vite" in x) && !d.some(x => "next" in x);
  for (const [p, t] of files) {
    if (!CODE.test(p) || /(^|\/)(supabase\/functions|api|server|scripts)\//.test(p) || /\.(test|spec)\.|\.d\.ts$/.test(p)) continue;
    if (!(isVite || /^\s*["']use client["']/.test(t))) continue;
    const ls = t.split("\n"), i = ls.findIndex(s => /service_?role/i.test(s) && !/^\s*(\/\/|\*|\/\*)/.test(s));
    if (i >= 0) out.push({ id: "sb-service-client", sev: "critical", path: p, line: i + 1 });
  }
  return out;
}
