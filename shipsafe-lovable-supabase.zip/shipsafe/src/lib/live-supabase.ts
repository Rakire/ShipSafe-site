// Live-site checks for Supabase apps. Only called for domains the user has proven they own.
// We read the site’s own JavaScript, then ask Supabase for at most one row per table using the PUBLIC key
// that every visitor already has. Row contents are never stored: only table and column names.
import { JWT_RE, SB_SECRET_RE, jwtClaims, jwtsIn } from "./jwt";
import type { Finding } from "./rules";
const T = () => ({ signal: AbortSignal.timeout(8000) });
const BUNDLE_SECRET = /AKIA[0-9A-Z]{16}|sk_live_[0-9a-zA-Z]{16,}|(?<![A-Za-z0-9])sk-(proj-)?[A-Za-z0-9_-]{32,}|gh[pousr]_[A-Za-z0-9]{36}|-----BEGIN (RSA |EC )?PRIVATE KEY-----/;
const SENSITIVE = /email|phone|mobile|password|token|secret|address|ssn|card|dob|birth|salary|payment/i;
async function capped(r: Response, max: number) {
  const rd = r.body?.getReader(); if (!rd) return "";
  const dec = new TextDecoder(); let out = "", n = 0;
  for (;;) { const { done, value } = await rd.read(); if (done) break; n += value.length; out += dec.decode(value, { stream: true }); if (n > max) { await rd.cancel(); break; } }
  return out;
}
// Follows redirects by hand, but only to the user’s own hostnames over HTTPS.
async function getSite(url: string, hosts: Set<string>): Promise<Response | null> {
  for (let i = 0; i < 4; i++) {
    const r = await fetch(url, { redirect: "manual", ...T() }).catch(() => null);
    if (!r) return null;
    if (r.status >= 300 && r.status < 400) {
      const loc = r.headers.get("location"); if (!loc) return null;
      let u: URL; try { u = new URL(loc, url); } catch { return null; }
      if (u.protocol !== "https:" || !hosts.has(u.hostname)) return null;
      url = u.href; continue;
    }
    return r;
  }
  return null;
}
export async function bundleChecks(domain: string): Promise<Finding[]> {
  const out: Finding[] = [], hosts = new Set([domain, "www." + domain, domain.replace(/^www\./, "")]);
  const home = await getSite(`https://${domain}/`, hosts);
  if (!home || !home.ok) return out;
  const html = await capped(home, 500_000), base = home.url || `https://${domain}/`;
  const urls = new Map<string, URL>();
  for (const m of html.matchAll(/<(?:script[^>]+src|link[^>]+href)=["']([^"']+\.m?js[^"']*)["']/gi)) {
    try { const u = new URL(m[1], base); if (u.protocol === "https:" && hosts.has(u.hostname)) urls.set(u.pathname, u); } catch {}
  }
  const texts: { name: string; text: string }[] = [{ name: "/", text: html }];
  for (const u of [...urls.values()].slice(0, 8)) {
    const r = await getSite(u.href, hosts);
    if (r?.ok) texts.push({ name: u.pathname, text: await capped(r, 3_000_000) });
  }
  let sbUrl: string | undefined, anon: string | undefined, publishable: string | undefined;
  const tables = new Set<string>();
  for (const { name, text } of texts) {
    if (SB_SECRET_RE.test(text) || jwtsIn(text).some(t => jwtClaims(t)?.role === "service_role")) out.push({ id: "live-service-key", sev: "critical", path: name, line: 0 });
    else if (BUNDLE_SECRET.test(text)) out.push({ id: "live-bundle-secret", sev: "critical", path: name, line: 0 });
    sbUrl ??= text.match(/https:\/\/[a-z0-9]{20}\.supabase\.co/)?.[0]; // hosted Supabase only, so a page can’t aim us at other servers
    publishable ??= text.match(/sb_publishable_[A-Za-z0-9_-]{20,}/)?.[0];
    for (const m of text.matchAll(/\.from\(\s*["'`]([a-z_][a-z0-9_]{0,62})["'`]\s*\)/gi)) tables.add(m[1]);
  }
  if (!sbUrl) return out;
  const ref = new URL(sbUrl).hostname.split(".")[0];
  for (const { text } of texts) for (const t of text.match(JWT_RE) ?? []) { const c = jwtClaims(t); if (c?.role === "anon" && (!c.ref || c.ref === ref)) { anon ??= t; break; } }
  const key = anon ?? publishable;
  if (!key) return out;
  const H: Record<string, string> = { apikey: key, ...(anon ? { Authorization: `Bearer ${anon}` } : {}) };
  const settings = await fetch(`${sbUrl}/auth/v1/settings`, { headers: { apikey: key }, ...T() }).then(r => (r.ok ? r.json() : null)).catch(() => null);
  if (settings?.mailer_autoconfirm === true && settings?.disable_signup !== true) out.push({ id: "live-autoconfirm", sev: "medium", path: new URL(sbUrl).hostname, line: 0 });
  // The API description lists every table when Supabase exposes it; otherwise we use table names found in the site’s code.
  const spec = await fetch(`${sbUrl}/rest/v1/`, { headers: H, ...T() }).then(r => (r.ok ? r.json() : null)).catch(() => null);
  const names = [...Object.keys(spec?.paths ?? {}).map(p => p.split("/")[1]), ...tables].filter(n => n && n !== "rpc" && /^[a-z_][a-z0-9_]{0,62}$/i.test(n));
  const probe = [...new Set(names)].slice(0, 40);
  for (let i = 0; i < probe.length; i += 5) await Promise.all(probe.slice(i, i + 5).map(async t => {
    const r = await fetch(`${sbUrl}/rest/v1/${encodeURIComponent(t)}?select=*&limit=1`, { headers: H, ...T() }).catch(() => null);
    if (!r || r.status !== 200) return;
    let rows: any; try { rows = JSON.parse(await capped(r, 200_000)); } catch { return; }
    if (!Array.isArray(rows) || !rows.length || typeof rows[0] !== "object") return; // [] means RLS hid everything (good) or the table is empty
    const cols = Object.keys(rows[0]);
    out.push({ id: "live-rls-read", sev: SENSITIVE.test(cols.join(" ")) ? "critical" : "high", path: t, line: 0, ev: "columns: " + cols.slice(0, 8).join(", ") });
  }));
  return out;
}
