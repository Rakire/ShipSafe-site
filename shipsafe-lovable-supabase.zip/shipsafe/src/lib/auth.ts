import { NextAuthOptions, getServerSession } from "next-auth";
import Credentials from "next-auth/providers/credentials";
import GitHub from "next-auth/providers/github";
import Google from "next-auth/providers/google";
import { hash, verify } from "@node-rs/argon2";
import { db } from "./db";
// Accepts an email or an Indian mobile number (10 digits, or with +91).
export const norm = (s: string): { email: string } | { mobile: string } | null => {
  s = s.trim();
  if (s.includes("@")) return /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(s) ? { email: s.toLowerCase() } : null;
  const d = s.replace(/\D/g, ""), m = d.length === 10 ? "91" + d : d;
  return /^91[6-9]\d{9}$/.test(m) ? { mobile: "+" + m } : null;
};
let dummy: Promise<string> | undefined;
const getDummy = () => (dummy ??= hash("not-a-real-password"));
// Social providers are enabled only when their keys are set.
export const providersOn = {
  github: !!(process.env.GITHUB_ID && process.env.GITHUB_SECRET),
  google: !!(process.env.GOOGLE_ID && process.env.GOOGLE_SECRET),
};
export const authOptions: NextAuthOptions = {
  pages: { signIn: "/login", error: "/login" },
  session: { strategy: "jwt", maxAge: 7 * 24 * 3600 },
  providers: [
    Credentials({ name: "Email or mobile", credentials: { id: {}, password: {} },
      async authorize(c) {
        const k = norm(String(c?.id ?? "")), pw = String(c?.password ?? "");
        const u = k ? await db.user.findFirst({ where: k }) : null;
        // Unknown user, or an account that only signs in with GitHub/Google: same timing, same answer.
        if (!u || !u.passwordHash) { await verify(await getDummy(), pw).catch(() => false); return null; }
        if (u.lockedUntil && u.lockedUntil > new Date()) return null;
        if (!(await verify(u.passwordHash, pw).catch(() => false))) {
          const n = u.failed + 1;
          await db.user.update({ where: { id: u.id }, data: n >= 5 ? { failed: 0, lockedUntil: new Date(Date.now() + 15 * 60e3) } : { failed: n } });
          return null;
        }
        await db.user.update({ where: { id: u.id }, data: { failed: 0, lockedUntil: null } });
        return { id: u.id, name: u.email ?? u.mobile };
      } }),
    ...(providersOn.github ? [GitHub({ clientId: process.env.GITHUB_ID!, clientSecret: process.env.GITHUB_SECRET! })] : []),
    ...(providersOn.google ? [Google({ clientId: process.env.GOOGLE_ID!, clientSecret: process.env.GOOGLE_SECRET! })] : []),
  ],
  callbacks: {
    async signIn({ account, user, profile }) {
      if (!account || account.provider === "credentials") return true;
      if (!user.email) return "/login?error=NoEmail";
      if (account.provider === "google" && !(profile as any)?.email_verified) return "/login?error=Unverified";
      return true; // GitHub only returns verified emails (public profile email or the verified primary one)
    },
    async jwt({ token, account, user }) {
      // On social sign-in, map the provider identity to our own User row so token.sub is always our user id.
      if (account && account.provider !== "credentials" && user?.email) {
        const email = user.email.toLowerCase();
        let u = await db.user.findUnique({ where: { email } });
        if (!u) u = await db.user.create({ data: { email, emailVerified: new Date() } });
        else if (!u.emailVerified) {
          // Password account that never proved it owns this email: drop its password so a squatter can't keep access.
          u = await db.user.update({ where: { id: u.id }, data: { emailVerified: new Date(), passwordHash: null, failed: 0, lockedUntil: null } });
        }
        token.sub = u.id;
      }
      return token;
    },
    async session({ session, token }) { (session as any).uid = token.sub; return session; },
  },
};
export const uid = async () => ((await getServerSession(authOptions)) as any)?.uid as string | undefined;
export const hashPw = (p: string) => hash(p);
