import PgBoss from "pg-boss";
let b: PgBoss | undefined;
export const queue = async () => { if (!b) { b = new PgBoss(process.env.DATABASE_URL!); await b.start(); await b.createQueue("scan"); } return b; };
