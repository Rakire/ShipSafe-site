import { db } from "./db";
export const scoreColor = (n: number) => (n >= 90 ? "#16a34a" : n >= 70 ? "#65a30d" : n >= 50 ? "#d97706" : "#dc2626");
// A badge always shows the latest finished scan of the same repo, so it stays current without anyone re-posting it.
// It is only available for public repos, or for private repos whose owner chose to share the report.
export async function badgeData(id: string) {
  const sel = { repoUrl: true, status: true, shared: true, isPrivate: true, userId: true, createdAt: true, score: true, stack: true } as const;
  const base = await db.scan.findUnique({ where: { id }, select: sel });
  if (!base || base.status !== "done" || !(base.shared || !base.isPrivate)) return null;
  const latest = await db.scan.findFirst({
    where: { repoUrl: base.repoUrl, status: "done", createdAt: { gte: base.createdAt }, ...(base.isPrivate ? { isPrivate: true, userId: base.userId } : { isPrivate: false }) },
    orderBy: { createdAt: "desc" }, select: sel });
  const s = latest ?? base;
  return { repo: base.repoUrl.replace("https://github.com/", ""), score: s.score, at: s.createdAt, stack: s.stack ?? base.stack ?? "" };
}
