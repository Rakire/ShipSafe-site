// Rules for Lovable + Supabase apps. Rules marked `test: none` are checked across the whole repo in supabase.ts
// or against the live site in live-supabase.ts; they live here so titles and fix prompts stay in one place.
import type { Rule } from "./rules";
import { hasServiceKey } from "./jwt";
const lines = (t: string, f: (s: string) => boolean) => t.split("\n").flatMap((s, i) => (f(s) ? [i + 1] : []));
const CODE = /\.(t|j)sx?$|\.(mjs|cjs|vue|svelte)$/;
const none = () => [] as number[];
export const SB_RULES: Rule[] = [
  { id: "sb-no-rls", sev: "critical", title: { en: "A database table is open to everyone (no row-level security)" },
    why: "In Supabase, anyone who has your public key can read and change a table unless Row Level Security (RLS) is switched on. Your public key is visible in every visitor’s browser, so this table is effectively public.",
    fix: "Turn on Row Level Security for the table named below. Then add policies so each signed-in user can only read and change their own rows (for example auth.uid() = user_id). Write it as a new Supabase migration and show me the SQL before running it.", test: none },
  { id: "sb-policy-open", sev: "critical", title: { en: "A database rule lets everyone in" },
    why: "This policy is set to “true”, which allows every request, including people who aren’t signed in. That is only right for data that is meant to be fully public.",
    fix: "Replace the always-true policy named below with one that checks the signed-in user, for example auth.uid() = user_id. Keep open read access only for tables whose data is meant to be public.", test: none },
  { id: "sb-policy-any-user", sev: "high", title: { en: "Any signed-in user can see or change everyone’s data" },
    why: "This policy only checks that someone is logged in. It doesn’t check whose row it is, so any user can reach every other user’s rows. Anyone can create an account, so this is almost the same as being public.",
    fix: "Change the policy named below so it also checks ownership, for example auth.uid() = user_id, or use a has_role() function for admin-only data.", test: none },
  { id: "sb-policy-metadata", sev: "high", title: { en: "A database rule trusts data that users can edit" },
    why: "user_metadata can be changed by the user themselves. A rule based on it (for example “role = admin”) can be bypassed by anyone.",
    fix: "Stop using user_metadata in the policy named below. Keep roles in a separate user_roles table that only the server can change, and check it through a security definer function such as has_role().", test: none },
  { id: "sb-definer", sev: "medium", title: { en: "A database function runs with extra power and no fixed search path" },
    why: "SECURITY DEFINER functions run with their owner’s rights. Without a fixed search_path, an attacker can trick them into calling a look-alike function.",
    fix: "Add SET search_path = public to the SECURITY DEFINER function named below (or SET search_path = '' and use full table names).", test: none },
  { id: "sb-view", sev: "medium", title: { en: "A database view skips row-level security" },
    why: "Views run with their owner’s rights by default, so they show every row even when the tables underneath have RLS. Anyone with your public key can read the view.",
    fix: "Recreate the view named below with security_invoker = true (CREATE VIEW ... WITH (security_invoker = true) AS ...) so it respects row-level security.", test: none },
  { id: "sb-bucket-public", sev: "medium", title: { en: "A file storage bucket is public" },
    why: "Anyone who knows or guesses a file’s address can download it. That is fine for logos and avatars, but not for invoices, IDs or private uploads. It may be a false alarm.",
    fix: "Check what is stored in the bucket named below. If any file is private, make the bucket private and serve files with short-lived signed URLs.", test: none },
  { id: "sb-service-key", sev: "critical", title: { en: "Your Supabase admin (service role) key is in the code" },
    why: "The service role key bypasses all row-level security. Anyone who finds it in your repo can read, change and delete your whole database.",
    fix: "My Supabase service role key is written in my code. Remove it, rotate it in the Supabase dashboard (Project Settings, API), and only use it inside a Supabase Edge Function through Deno.env.get(\"SUPABASE_SERVICE_ROLE_KEY\"). Never put it in front-end code.",
    test: (_p, t) => lines(t, hasServiceKey) },
  { id: "sb-service-client", sev: "critical", title: { en: "The admin key is used in code that runs in the browser" },
    why: "Everything in a Lovable or Vite app’s src folder is sent to the visitor’s browser. Using the service role key here exposes it to everyone.",
    fix: "Stop using the Supabase service role key in front-end code. Move that logic into a Supabase Edge Function that checks the caller is signed in, and call the function from the app. Then rotate the service role key.", test: none },
  { id: "sb-edge-noauth", sev: "high", title: { en: "A backend function uses the admin key without checking who is calling" },
    why: "The public key is also a valid login token, so anyone can call this function. Because it uses the admin key, it can read or change anything on the caller’s behalf.",
    fix: "In the Edge Function shown below, read the Authorization header, call supabase.auth.getUser(token) and return 401 if there is no user. Check the user is allowed to do this action before using the service role client.",
    test: (p, t) => {
      if (!/(^|\/)supabase\/functions\/.+\.(t|j)sx?$/.test(p) || !/SERVICE_ROLE/.test(t)) return [];
      if (/auth\.getUser\(|getClaims\(|jwtVerify|verifyJWT|constructEvent|stripe-signature|x-hub-signature|svix|webhook-signature/i.test(t)) return [];
      return lines(t, s => /SERVICE_ROLE/.test(s)).slice(0, 1);
    } },
  { id: "sb-verify-jwt-off", sev: "medium", title: { en: "A backend function skips Supabase’s login check" },
    why: "verify_jwt = false lets anyone on the internet call the function without even the public key. That is normal for webhooks, but risky for anything else.",
    fix: "Check each function marked verify_jwt = false in supabase/config.toml. Turn it back on unless the function is a webhook that verifies its own signature.",
    test: (p, t) => (/(^|\/)supabase\/config\.toml$/.test(p) ? lines(t, s => /^\s*verify_jwt\s*=\s*false/.test(s)) : []) },
  { id: "client-admin", sev: "high", title: { en: "Admin status is checked in the browser" },
    why: "Anything stored in the browser (localStorage, sessionStorage) can be edited by the visitor. If the app trusts it to decide who is an admin, anyone can make themselves one.",
    fix: "Stop reading admin or role flags from localStorage or sessionStorage. Check roles on the server with a database policy or Edge Function that reads a user_roles table, and treat any browser-side check as display only.",
    test: (p, t) => (CODE.test(p) ? lines(t, s => /(localStorage|sessionStorage)\.(get|set)Item\(\s*["'`](is_?admin|admin|role|user_?role)["'`]/i.test(s)) : []) },
  // Live-site checks (live-supabase.ts)
  { id: "live-rls-read", sev: "high", title: { en: "Anyone on the internet can read a table from your live app" },
    why: "We asked your live Supabase database for one row using only the public key from your website, exactly like any visitor could, and it handed one over. The table named below has no working row-level security.",
    fix: "The Supabase table named below can be read by anyone with my public key. Turn on Row Level Security for it and add policies so users can only read their own rows. Then check the other tables the same way and show me the SQL.", test: none },
  { id: "live-service-key", sev: "critical", title: { en: "Your admin key is inside your live website’s code" },
    why: "The Supabase service role key is in a file your website sends to every visitor. Anyone can open it in the browser and take full control of your database.",
    fix: "My live website exposes my Supabase service role key. Rotate the key in the Supabase dashboard now, remove every use of it from front-end code, and move that logic into a Supabase Edge Function. Then redeploy.", test: none },
  { id: "live-bundle-secret", sev: "critical", title: { en: "A secret key is inside your live website’s code" },
    why: "A private key (for example an OpenAI, Stripe or AWS key) is in a file your website sends to every visitor. Anyone can copy it and run up your bill or read your data.",
    fix: "A secret key is shipped in my website’s JavaScript. Rotate that key with its provider now, move the call that uses it into a server-side function or Supabase Edge Function, and read the key from a server-only secret.", test: none },
  { id: "live-autoconfirm", sev: "medium", title: { en: "Anyone can sign up without confirming their email" },
    why: "Email confirmation is off in your Supabase project, so people can create accounts with email addresses they don’t own. That makes spam and fake accounts easy.",
    fix: "In the Supabase dashboard open Authentication, then Providers, then Email, and turn on “Confirm email”.", test: none },
];
