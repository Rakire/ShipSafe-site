// Sends plain-text email through Resend. Swap the fetch for any provider you like.
export async function sendMail(to: string, subject: string, text: string) {
  const key = process.env.RESEND_API_KEY;
  if (!key) {
    // Never print reset links in production logs.
    if (process.env.NODE_ENV !== "production") console.log(`\n[mail:dev] to=${to}\nsubject=${subject}\n${text}\n`);
    else console.error("RESEND_API_KEY is not set; email not sent");
    return;
  }
  const r = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { authorization: `Bearer ${key}`, "content-type": "application/json" },
    body: JSON.stringify({ from: process.env.MAIL_FROM, to, subject, text }),
  });
  if (!r.ok) console.error("mail failed", r.status);
}
