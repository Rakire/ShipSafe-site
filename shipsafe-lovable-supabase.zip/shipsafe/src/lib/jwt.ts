// Helpers for spotting Supabase keys. A Supabase key is a JWT whose payload says which role it grants.
export const JWT_RE = /eyJ[\w-]{8,}\.eyJ[\w-]{8,}\.[\w-]{8,}/g;
export const SB_SECRET_RE = /sb_secret_[A-Za-z0-9_-]{20,}/;
export function jwtClaims(tok: string): { role?: string; ref?: string } | null {
  try { return JSON.parse(Buffer.from(tok.split(".")[1], "base64url").toString("utf8")); } catch { return null; }
}
export const jwtsIn = (s: string) => s.match(JWT_RE) ?? [];
export const hasServiceKey = (s: string) => SB_SECRET_RE.test(s) || jwtsIn(s).some(t => jwtClaims(t)?.role === "service_role");
