import { notFound } from "next/navigation";
import { badgeData, scoreColor } from "@/lib/badge";
export const dynamic = "force-dynamic";
// Public page behind the badge. It shows the score only, never the list of problems.
export default async function Page({ params }: { params: Promise<{ id: string }> }) {
  const id = (await params).id, b = await badgeData(id);
  if (!b) notFound();
  const tags = b.stack.split(",").filter(x => x === "lovable" || x === "supabase");
  return <main className="mx-auto max-w-xl p-4">
    <p className="break-all text-sm text-slate-500">{b.repo}</p>
    <p className="my-2 text-5xl font-bold" style={{ color: scoreColor(b.score) }}>{b.score}<span className="text-2xl text-slate-500">/100</span></p>
    <p className="text-sm text-slate-500">ShipSafe security score · checked {b.at.toISOString().slice(0, 10)}{tags.length ? ` · ${tags.join(" + ")}` : ""}</p>
    <p className="my-4">ShipSafe reads the code for open Supabase tables, leaked keys and risky settings. The owner can also check the running website. Only the score is public.</p>
    <a href="/" className="inline-block rounded-lg bg-indigo-600 px-5 py-3 font-semibold text-white">Scan your own app free</a>
  </main>;
}
