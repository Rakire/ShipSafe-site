"use client";
import { useState } from "react";
import { useT } from "../ui";
import { input, primary } from "../auth-ui";
export default function ForgotForm() {
  const t = useT(), [id, setId] = useState(""), [msg, setMsg] = useState(""), [err, setErr] = useState(""), [b, setB] = useState(false);
  async function go(e: React.FormEvent) {
    e.preventDefault(); setErr(""); setMsg("");
    if (!id.includes("@")) { setErr(t("email_only")); return; }
    setB(true);
    const r = await fetch("/api/password/forgot", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ id }) });
    setB(false);
    if (r.ok) setMsg(t("check_email")); else setErr((await r.json().catch(() => ({}))).error ?? "Something went wrong. Try again.");
  }
  return <main className="mx-auto max-w-sm p-4">
    <h1 className="mb-4 text-2xl font-bold">{t("forgot_title")}</h1>
    <form onSubmit={go} className="flex flex-col gap-3">
      <label htmlFor="id" className="font-semibold">{t("id")}</label>
      <input id="id" required autoComplete="username" inputMode="email" value={id} onChange={e => setId(e.target.value)} className={input} />
      <p role="alert" className="min-h-6 text-sm text-red-600">{err}</p>
      {msg && <p role="status" className="rounded-lg border border-green-600 p-3 text-sm">{msg}</p>}
      <button disabled={b} className={primary}>{t("send_link")}</button>
    </form>
    <a href="/login" className="mt-4 inline-block text-sm font-semibold text-indigo-600 dark:text-indigo-400">{t("back_login")}</a>
  </main>;
}
