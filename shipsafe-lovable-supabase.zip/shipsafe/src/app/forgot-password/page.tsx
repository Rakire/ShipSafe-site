import ForgotForm from "./forgot-form";
export default function Page() { return <ForgotForm />; }
