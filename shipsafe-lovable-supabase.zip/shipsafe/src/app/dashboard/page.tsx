"use client";
import { useEffect, useState } from "react";
import { useT } from "../ui";
const post = (u: string, b: object) => fetch(u, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(b) }).then(r => r.json());
export default function Dash() {
  const t = useT();
  const [d, setD] = useState<any>(null), [sc, setSc] = useState<any[]>([]), [url, setUrl] = useState(""), [inst, setInst] = useState("");
  const [dom, setDom] = useState<Record<string, string>>({}), [msg, setMsg] = useState<Record<string, string>>({});
  const load = async () => {
    const r = await fetch("/api/projects");
    if (r.status === 401) { location.href = "/login"; return; }
    setD(await r.json()); setSc(await (await fetch("/api/scans")).json());
  };
  useEffect(() => { load(); }, []);
  const act = async (id: string, body: object) => {
    const j = await post("/api/projects/" + id, body);
    const m = j.error ?? (j.url ? "Pull request: " + j.url : j.findings ? `${j.findings.length} live issue(s) found.` : j.verified === undefined ? "Saved." : j.verified ? "Domain verified." : "Not verified yet. Check the DNS record or file.");
    setMsg(x => ({ ...x, [id]: m })); load();
  };
  const scan = async (u: string) => { const j = await post("/api/scans", { url: u }); if (j.id) location.href = "/scan/" + j.id; else alert(j.error); };
  if (!d) return <main className="p-4">{t("wait")}</main>;
  return <main className="mx-auto max-w-3xl p-4">
    <h1 className="mb-2 text-2xl font-bold">{t("dashboard")}</h1>
    <p className="mb-4">Plan: <b>{d.plan}</b> {d.plan === "free" && <button className="ml-2 rounded bg-indigo-600 px-3 py-1 text-white" onClick={async () => { const j = await post("/api/billing/checkout", {}); if (j.url) location.href = j.url; }}>Upgrade ({process.env.NEXT_PUBLIC_PRICE_LABEL ?? "99 per month"})</button>}</p>
    <h2 className="mb-2 text-xl font-semibold">Projects</h2>
    <form className="mb-4 flex flex-col gap-2 sm:flex-row" onSubmit={async e => { e.preventDefault(); const j = await post("/api/projects", { url, installationId: inst }); if (j.error) alert(j.error); setUrl(""); setInst(""); load(); }}>
      <input required value={url} onChange={e => setUrl(e.target.value)} placeholder="https://github.com/owner/repo" aria-label="Repository link" className="flex-1 rounded border bg-transparent p-2" />
      <input value={inst} onChange={e => setInst(e.target.value)} placeholder="GitHub App installation ID (optional)" aria-label="Installation ID" className="rounded border bg-transparent p-2" />
      <button className="rounded bg-indigo-600 px-4 py-2 text-white">Add</button>
    </form>
    {d.projects.map((p: any) => <section key={p.id} className="mb-3 rounded-xl border p-4">
      <p className="font-semibold">{p.owner}/{p.repo}</p>
      <div className="my-2 flex flex-wrap gap-2">
        <button className="rounded border px-3 py-1" onClick={() => scan(`https://github.com/${p.owner}/${p.repo}`)}>{t("scan")}</button>
        <button className="rounded border px-3 py-1" onClick={() => act(p.id, { action: "fix" })}>Open fix pull request</button>
      </div>
      <div className="mt-3 rounded-lg bg-slate-100 p-3 dark:bg-slate-900">
        <p className="font-semibold">Live site check{p.liveScore !== null && <span className="ml-2 font-normal text-slate-500">{p.domain}: {p.liveScore}/100</span>}</p>
        <p className="mb-2 text-xs text-slate-500">Looks at your running website like an outsider would. We only read what any visitor can read: at most one row per table, never stored.</p>
        <ol className="mb-2 flex flex-wrap gap-x-4 text-sm">
          <li>{p.domain ? "✓" : "1."} Add domain</li><li>{p.domainVerified ? "✓" : "2."} Verify ownership</li><li>{p.liveCheckedAt ? "✓" : "3."} Run live check</li>
        </ol>
        <div className="flex flex-col gap-2 sm:flex-row">
          <input value={dom[p.id] ?? p.domain ?? ""} onChange={e => setDom({ ...dom, [p.id]: e.target.value })} placeholder="yourapp.com or yourapp.lovable.app" aria-label="Domain" className="flex-1 rounded border bg-transparent p-2" />
          <button className="rounded border px-3 py-1" onClick={() => act(p.id, { action: "domain", domain: dom[p.id] ?? p.domain })}>Save domain</button>
          {p.domain && !p.domainVerified && <button className="rounded border px-3 py-1" onClick={() => act(p.id, { action: "verify" })}>Verify</button>}
          {p.domainVerified && <button className="rounded bg-indigo-600 px-3 py-1 text-white" onClick={() => act(p.id, { action: "live" })}>Run live check</button>}
        </div>
        {p.domain && !p.domainVerified && <div className="mt-2 text-sm">
          <p className="break-all text-slate-500">To prove you own it, add a DNS TXT record <code>_shipsafe.{p.domain}</code> with value <code>shipsafe={p.domainToken}</code>, or host a file at <code>/.well-known/shipsafe.txt</code> containing <code>{p.domainToken}</code>.</p>
          <p className="mt-1">On Lovable you can’t edit DNS for a lovable.app address, so use the file:</p>
          <button className="mt-1 rounded border px-3 py-1" onClick={() => { navigator.clipboard.writeText(`Create a file at public/.well-known/shipsafe.txt that contains exactly this text and nothing else: ${p.domainToken}\nThen publish the site.`); setMsg(x => ({ ...x, [p.id]: "Prompt copied. Paste it into Lovable, publish, then press Verify." })); }}>Copy Lovable prompt</button>
        </div>}
        {p.liveFindings.map((f: any, i: number) => <article key={i} className="mt-3 rounded-lg border p-3">
          <span className={`rounded px-2 py-0.5 text-xs font-bold text-white ${f.sev === "critical" ? "bg-red-600" : f.sev === "high" ? "bg-orange-600" : "bg-amber-600"}`}>{f.sev}</span>
          <p className="mt-1 font-semibold">{f.title}</p>
          <p className="break-all text-sm text-slate-500">{f.path}{f.ev ? ` (${f.ev})` : ""}</p>
          <p className="my-1 text-sm">{f.why}</p>
          <button className="rounded bg-indigo-600 px-3 py-1 text-sm text-white" onClick={() => { navigator.clipboard.writeText(`${f.fix}\n\nWhere: ${f.path}${f.ev ? ` (${f.ev})` : ""}`); setMsg(x => ({ ...x, [p.id]: "Fix prompt copied." })); }}>Copy fix prompt</button>
        </article>)}
      </div>
      <p role="status" className="mt-1 text-sm">{msg[p.id]}</p>
    </section>)}
    <h2 className="mb-2 mt-6 text-xl font-semibold">Recent scans</h2>
    {sc.map(s => <p key={s.id}><a className="underline" href={"/scan/" + s.id}>{s.repoUrl.replace("https://github.com/", "")}</a> {s.status === "done" ? `${s.score}/100` : s.status}</p>)}
  </main>;
}
