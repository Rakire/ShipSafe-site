import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { uid } from "@/lib/auth";
import { RULES } from "@/lib/rules";
export const dynamic = "force-dynamic";
// Founder-only page: how many real builders have scanned, and how many of the findings they rated were useful.
export default async function Page() {
  const u = await uid(), user = u ? await db.user.findUnique({ where: { id: u } }) : null;
  const admins = (process.env.ADMIN_EMAILS ?? "").split(",").map(x => x.trim().toLowerCase()).filter(Boolean);
  if (!user?.email || !admins.includes(user.email.toLowerCase())) notFound();
  const goal = Number(process.env.VALIDATION_GOAL ?? 20);
  const scans = await db.scan.findMany({ where: { status: "done" }, orderBy: { createdAt: "desc" }, take: 2000, select: { userId: true, ipHash: true, stack: true, findings: true } });
  const all = new Set<string>(), sb = new Set<string>(), shown: Record<string, number> = {};
  for (const s of scans) {
    const b = s.userId ?? s.ipHash ?? "?";
    all.add(b); if (s.stack?.includes("supabase")) sb.add(b);
    for (const f of s.findings as any[]) shown[f.id] = (shown[f.id] ?? 0) + 1;
  }
  const fb = await db.feedback.findMany({ select: { ruleId: true, verdict: true, voter: true, scan: { select: { stack: true } } } });
  const raters = new Set(fb.map(x => x.voter)), sbRaters = new Set(fb.filter(x => x.scan.stack?.includes("supabase")).map(x => x.voter));
  const per: Record<string, { u: number; f: number }> = {};
  for (const x of fb) { const r = (per[x.ruleId] ??= { u: 0, f: 0 }); if (x.verdict === "useful") r.u++; else r.f++; }
  const useful = fb.filter(x => x.verdict === "useful").length, pct = (a: number, b: number) => (b ? Math.round((a / b) * 100) + "%" : "–");
  const rows = Object.entries(per).map(([id, r]) => ({ id, ...r, n: r.u + r.f, shown: shown[id] ?? 0 })).sort((a, b) => b.n - a.n);
  const stat = (label: string, value: string, sub?: string) => <div className="rounded-xl border p-4"><p className="text-sm text-slate-500">{label}</p><p className="text-3xl font-bold">{value}</p>{sub && <p className="text-xs text-slate-500">{sub}</p>}</div>;
  return <main className="mx-auto max-w-3xl p-4">
    <h1 className="mb-1 text-2xl font-bold">Validation</h1>
    <p className="mb-4 text-sm text-slate-500">Goal: {goal} real builders scan their own apps and rate what we found. Only ratings from the person who ran the scan count.</p>
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
      {stat("Lovable/Supabase builders scanned", `${sb.size} / ${goal}`, `${all.size} builders in total`)}
      {stat("Builders who rated findings", `${sbRaters.size} / ${goal}`, `${raters.size} in total`)}
      {stat("Findings rated", String(fb.length))}
      {stat("Rated useful", pct(useful, fb.length), `${useful} useful, ${fb.length - useful} false alarms`)}
    </div>
    <h2 className="mb-2 mt-6 text-xl font-semibold">By rule</h2>
    <p className="mb-2 text-sm text-slate-500">“Useful” is the share of rated findings the builder called useful. Rules with at least 5 ratings and 40% or more false alarms should be tuned or removed.</p>
    <div className="overflow-x-auto"><table className="w-full text-left text-sm">
      <thead><tr className="border-b"><th className="p-2">Rule</th><th className="p-2">Shown</th><th className="p-2">Rated</th><th className="p-2">Useful</th><th className="p-2"></th></tr></thead>
      <tbody>{rows.map(r => <tr key={r.id} className="border-b">
        <td className="p-2">{RULES.find(x => x.id === r.id)?.title.en ?? r.id}<br /><code className="text-xs text-slate-500">{r.id}</code></td>
        <td className="p-2">{r.shown}</td><td className="p-2">{r.n}</td><td className="p-2">{pct(r.u, r.n)}</td>
        <td className="p-2 font-semibold text-red-600">{r.n >= 5 && r.f / r.n >= 0.4 ? "Tune or remove" : ""}</td></tr>)}</tbody>
    </table></div>
    {!rows.length && <p className="mt-2">No ratings yet. Ask builders to open their report and tap Useful or False alarm on each finding.</p>}
  </main>;
}
