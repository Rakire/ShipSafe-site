"use client";
import { useState } from "react";
import { useT } from "./ui";

// Only follow same-site destinations (blocks open redirects like //evil.com).
export function safeNext(raw?: string | null) {
  try { const u = new URL(raw || "/dashboard", location.origin); return u.origin === location.origin ? u.pathname + u.search : "/dashboard"; }
  catch { return "/dashboard"; }
}
export const input = "w-full rounded-lg border bg-transparent p-3";
export const primary = "rounded-lg bg-indigo-600 p-3 font-semibold text-white disabled:opacity-60";

export function PasswordField({ id, label, value, onChange, autoComplete }: { id: string; label: string; value: string; onChange: (v: string) => void; autoComplete: string }) {
  const t = useT(), [show, setShow] = useState(false);
  return <div className="flex flex-col gap-1">
    <label htmlFor={id} className="font-semibold">{label}</label>
    <div className="relative">
      <input id={id} type={show ? "text" : "password"} required minLength={10} maxLength={128} autoComplete={autoComplete} value={value} onChange={e => onChange(e.target.value)} className={input + " pr-20"} />
      <button type="button" aria-pressed={show} onClick={() => setShow(s => !s)} className="absolute inset-y-0 right-1 px-3 text-sm font-semibold text-indigo-600 dark:text-indigo-400">{show ? t("hide") : t("show")}</button>
    </div>
  </div>;
}

const score = (p: string) => {
  let s = 0;
  if (p.length >= 10) s++;
  if (p.length >= 14) s++;
  if (/[a-z]/.test(p) && /[A-Z]/.test(p)) s++;
  if (/\d/.test(p) && /[^A-Za-z0-9]/.test(p)) s++;
  return p ? Math.max(1, s) : 0;
};
export function Strength({ pw }: { pw: string }) {
  const t = useT(), s = score(pw), label = ["", "weak", "fair", "good", "strong"][s];
  const color = ["", "bg-red-500", "bg-orange-500", "bg-yellow-500", "bg-green-600"][s];
  return <div aria-live="polite" className="min-h-8">
    <div className="flex gap-1" aria-hidden>{[1, 2, 3, 4].map(i => <div key={i} className={`h-1.5 flex-1 rounded ${i <= s ? color : "bg-slate-300 dark:bg-slate-700"}`} />)}</div>
    {label && <p className="mt-1 text-xs">{t(label)}</p>}
  </div>;
}
