"use client";
import { useEffect, useState } from "react";
import { T, langOf, Lang } from "@/lib/i18n";
export function useT() {
  const [l, setL] = useState<Lang>("en");
  useEffect(() => { setL(langOf(document.cookie.match(/lang=(\w+)/)?.[1])); }, []);
  return (k: string) => T[l][k] ?? T.en[k] ?? k;
}
export function Nav() {
  const t = useT();
  const set = (l: string) => { document.cookie = `lang=${l};path=/;max-age=31536000;samesite=lax`; location.reload(); };
  return <nav className="mx-auto flex max-w-3xl flex-wrap items-center justify-between gap-2 p-4">
    <a href="/" className="text-lg font-bold">ShipSafe</a>
    <div className="flex flex-wrap items-center gap-3 text-sm">
      <a href="/dashboard">{t("dashboard")}</a><a href="/login">{t("signin")}</a><a href="/signup">{t("signup")}</a>
      <select aria-label="Language" defaultValue="" onChange={e => set(e.target.value)} className="rounded border bg-transparent p-1">
        <option value="" disabled>🌐</option><option value="en">English</option><option value="te">తెలుగు</option><option value="hi">हिन्दी</option>
      </select>
    </div>
  </nav>;
}
