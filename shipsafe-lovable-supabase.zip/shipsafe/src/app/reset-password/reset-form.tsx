"use client";
import { useState } from "react";
import { useT } from "../ui";
import { PasswordField, Strength, primary } from "../auth-ui";
export default function ResetForm({ token }: { token: string }) {
  const t = useT(), [pw, setPw] = useState(""), [pw2, setPw2] = useState(""), [err, setErr] = useState(""), [done, setDone] = useState(false), [b, setB] = useState(false);
  async function go(e: React.FormEvent) {
    e.preventDefault(); setErr("");
    if (pw !== pw2) { setErr(t("mismatch")); return; }
    setB(true);
    const r = await fetch("/api/password/reset", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ token, password: pw }) });
    setB(false);
    if (r.ok) { setDone(true); return; }
    const e2 = (await r.json().catch(() => ({}))).error;
    setErr(e2 === "bad_link" ? t("bad_link") : e2 ?? "Something went wrong. Try again.");
  }
  if (!token) return <main className="mx-auto max-w-sm p-4"><p role="alert" className="mb-4 text-red-600">{t("bad_link")}</p><a href="/forgot-password" className="font-semibold text-indigo-600 dark:text-indigo-400">{t("send_link")}</a></main>;
  return <main className="mx-auto max-w-sm p-4">
    <h1 className="mb-4 text-2xl font-bold">{t("forgot_title")}</h1>
    {done ? <>
      <p role="status" className="mb-4 rounded-lg border border-green-600 p-3">{t("reset_done")}</p>
      <a href="/login" className={primary + " block text-center"}>{t("signin")}</a>
    </> : <form onSubmit={go} className="flex flex-col gap-3">
      <PasswordField id="pw" label={t("new_password")} value={pw} onChange={setPw} autoComplete="new-password" />
      <Strength pw={pw} />
      <PasswordField id="pw2" label={t("confirm_password")} value={pw2} onChange={setPw2} autoComplete="new-password" />
      <p role="alert" className="min-h-6 text-sm text-red-600">{err}</p>
      <button disabled={b} className={primary}>{t("reset_btn")}</button>
    </form>}
  </main>;
}
