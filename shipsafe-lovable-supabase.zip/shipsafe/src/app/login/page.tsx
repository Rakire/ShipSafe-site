import { redirect } from "next/navigation";
import AuthForm from "../auth-form";
import { uid, providersOn } from "@/lib/auth";
export default async function Page({ searchParams }: { searchParams: Promise<{ callbackUrl?: string; error?: string }> }) {
  if (await uid()) redirect("/dashboard");
  const sp = await searchParams;
  return <AuthForm mode="login" callbackUrl={sp.callbackUrl} error={sp.error} providers={providersOn} />;
}
