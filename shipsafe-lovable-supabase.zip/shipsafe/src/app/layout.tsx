import "./globals.css";
import { Nav } from "./ui";
export const metadata = { title: "ShipSafe" };
export default function L({ children }: { children: React.ReactNode }) { return <html lang="en"><body><Nav />{children}</body></html>; }
