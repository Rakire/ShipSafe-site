"use client";
import { use, useEffect, useState } from "react";
import { useT } from "../../ui";
const cls: any = { critical: "bg-red-600", high: "bg-orange-600", medium: "bg-amber-600" };
const TAG: any = { lovable: "Lovable", supabase: "Supabase" };
export default function Scan({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params), t = useT();
  const [d, setD] = useState<any>(null), [c, setC] = useState(""), [sh, setSh] = useState(false), [v, setV] = useState<Record<string, string | null>>({});
  useEffect(() => {
    let on = true;
    const tick = async () => { const j = await (await fetch("/api/scans/" + id)).json(); if (!on) return; setD(j); if (["queued", "running"].includes(j.status)) setTimeout(tick, 2000); };
    tick(); return () => { on = false; };
  }, [id]);
  if (!d) return <main className="p-4">{t("wait")}</main>;
  if (!d.status) return <main className="p-4">{d.error}</main>;
  if (["queued", "running"].includes(d.status)) return <main className="p-4">{t("wait")}</main>;
  if (d.status === "failed") return <main className="p-4 text-red-600">{d.error}</main>;
  const copyText = async (text: string, k: string) => { await navigator.clipboard.writeText(text).catch(() => {}); setC(k); };
  const k = (f: any) => f.path + f.line + f.id;
  const vote = async (f: any, verdict: string) => {
    const cur = k(f) in v ? v[k(f)] : f.vote, next = cur === verdict ? null : verdict;
    setV(x => ({ ...x, [k(f)]: next }));
    await fetch("/api/feedback", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ scanId: id, key: f.key, verdict: next }) });
  };
  const card = (f: any, i: number) => {
    const cur = k(f) in v ? v[k(f)] : f.vote;
    return <article key={i} className="mb-3 rounded-xl border p-4">
      <span className={`rounded px-2 py-0.5 text-xs font-bold text-white ${cls[f.sev]}`}>{t(f.sev)}</span>
      <h3 className="mt-2 font-semibold">{f.title}</h3>
      <p className="break-all text-sm text-slate-500">{t("where")}: {f.path}{f.line ? `:${f.line}` : ""}{f.ev ? ` (${f.ev})` : ""}</p>
      <p className="my-2">{f.why}</p>
      <p className="text-sm font-semibold">{t("fix")}</p>
      <p className="mb-2 text-sm">{f.fix}</p>
      <div className="flex flex-wrap items-center gap-2">
        <button onClick={() => copyText(`${f.fix}\n\nWhere: ${f.path}${f.ev ? ` (${f.ev})` : ""}${f.line ? `, line ${f.line}` : ""}`, k(f))} className="rounded bg-indigo-600 px-3 py-1 text-sm text-white">{c === k(f) ? t("copied") : t("copy")}</button>
        {d.mine && <span className="ml-auto flex items-center gap-1 text-sm"><span className="text-slate-500">{t("useful_q")}</span>
          <button aria-pressed={cur === "useful"} onClick={() => vote(f, "useful")} className={`rounded border px-2 py-1 ${cur === "useful" ? "border-green-600 bg-green-600 text-white" : ""}`}>{t("useful")}</button>
          <button aria-pressed={cur === "false_alarm"} onClick={() => vote(f, "false_alarm")} className={`rounded border px-2 py-1 ${cur === "false_alarm" ? "border-slate-600 bg-slate-600 text-white" : ""}`}>{t("false_alarm")}</button></span>}
      </div>
    </article>;
  };
  const tags = String(d.stack).split(",").filter((x: string) => TAG[x]).map((x: string) => TAG[x]);
  const lv = d.live;
  return <main className="mx-auto max-w-3xl p-4">
    <p className="break-all text-sm text-slate-500">{d.repoUrl}{tags.length > 0 && <span> · {t("stack_l")}: {tags.join(" + ")}</span>}</p>
    <p className="my-2 text-2xl font-bold">{t("score")}: {d.score}/100</p>
    {d.owner && !d.shared && <button className="mb-3 rounded border px-3 py-1" onClick={async () => { await fetch("/api/scans/" + id, { method: "POST" }); setSh(true); await navigator.clipboard.writeText(location.href).catch(() => {}); }}>{sh ? t("copied") : t("share")}</button>}
    {d.badge && <section className="mb-4 rounded-xl border p-4">
      <h2 className="font-semibold">{t("badge_h")}</h2>
      <p className="my-1 text-sm text-slate-500">{t("badge_p")}</p>
      <img src={d.badge.img} alt="ShipSafe score" height={20} className="my-2" />
      <div className="flex flex-wrap gap-2">
        <button className="rounded border px-3 py-1 text-sm" onClick={() => copyText(`[![ShipSafe score](${d.badge.img})](${d.badge.link})`, "md")}>{c === "md" ? t("copied") : t("copy_md")}</button>
        <button className="rounded border px-3 py-1 text-sm" onClick={() => copyText(`<a href="${d.badge.link}"><img src="${d.badge.img}" alt="ShipSafe security score" height="20"></a>`, "html")}>{c === "html" ? t("copied") : t("copy_html")}</button>
      </div>
    </section>}
    <h2 className="mb-2 text-xl font-semibold">{t("top")}</h2>
    {!d.findings.length && <p>{t("clean")}</p>}
    {d.findings.map(card)}
    {d.total > d.findings.length && <p className="font-semibold">{d.total - d.findings.length} {t("locked")} <a className="underline" href="/signup">{t("signup")}</a></p>}
    {lv && <section className="mt-8">
      <h2 className="mb-1 text-xl font-semibold">{t("live_h")}{lv.score !== null && <span className="ml-2 text-base font-normal text-slate-500">{lv.domain}: {lv.score}/100</span>}</h2>
      {!lv.hasProject && <p className="text-sm">Add this repo as a project in your <a className="underline" href="/dashboard">dashboard</a>, prove you own your domain, and we will check your running website too. It catches problems the code can’t show, like tables a stranger can read.</p>}
      {lv.hasProject && !lv.verified && <p className="text-sm">Verify your domain in the <a className="underline" href="/dashboard">dashboard</a> to turn on the live check.</p>}
      {lv.verified && !lv.findings.length && <p>{lv.checkedAt ? t("clean") : "Run the live check from your dashboard."}</p>}
      {lv.findings.map(card)}
    </section>}
    {!d.mine && <p className="mt-8 rounded-xl border p-4"><a className="font-semibold underline" href="/">{t("scan_yours")}</a></p>}
  </main>;
}
