import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { uid } from "@/lib/auth";
import { ipHashOf } from "@/lib/voter";
import { parseRepo } from "@/lib/github";
import { limited } from "@/lib/limit";
const err = (m: string, s: number) => NextResponse.json({ error: m }, { status: s });
// Lets the person who ran a scan mark each finding "useful" or "false alarm". These ratings drive the validation page.
export async function POST(req: Request) {
  const ip = ipHashOf(req);
  if (limited(`fb:${ip}`, 200, 3600e3)) return err("Too many ratings. Try again later.", 429);
  const { scanId, key, verdict } = await req.json().catch(() => ({}));
  if (verdict !== null && verdict !== "useful" && verdict !== "false_alarm") return err("Unknown rating.", 400);
  const s = await db.scan.findUnique({ where: { id: String(scanId ?? "") } });
  if (!s) return err("Report not found.", 404);
  const u = await uid(), k = String(key ?? "");
  if (!((!!u && s.userId === u) || (!s.userId && s.ipHash === ip))) return err("Only the person who ran this scan can rate its findings.", 403);
  const same = (f: any) => `${f.id}|${f.path}|${f.line}` === k;
  let ruleId: string | undefined = (s.findings as any[]).find(same)?.id;
  if (!ruleId && u) { // live-site findings belong to the project, not the scan
    const r = parseRepo(s.repoUrl);
    const p = r ? await db.project.findFirst({ where: { userId: u, owner: { equals: r.owner, mode: "insensitive" }, repo: { equals: r.repo, mode: "insensitive" } } }) : null;
    ruleId = ((p?.liveFindings as any[]) ?? []).find(same)?.id;
  }
  if (!ruleId) return err("Finding not found.", 404);
  const voter = u ?? ip;
  if (verdict === null) await db.feedback.deleteMany({ where: { scanId: s.id, findingKey: k, voter } });
  else await db.feedback.upsert({ where: { scanId_findingKey_voter: { scanId: s.id, findingKey: k, voter } }, update: { verdict }, create: { scanId: s.id, ruleId, findingKey: k, verdict, voter } });
  return NextResponse.json({ ok: true });
}
