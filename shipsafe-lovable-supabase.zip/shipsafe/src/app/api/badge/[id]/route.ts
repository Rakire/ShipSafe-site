import { badgeData, scoreColor } from "@/lib/badge";
const esc = (s: string) => s.replace(/[<>&"]/g, c => ({ "<": "&lt;", ">": "&gt;", "&": "&amp;", '"': "&quot;" })[c]!);
function svg(label: string, value: string, color: string) {
  const w = (s: string) => Math.round(s.length * 6.6 + 14), lw = w(label), vw = w(value), W = lw + vw;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="20" role="img" aria-label="${esc(label)}: ${esc(value)}"><title>${esc(label)}: ${esc(value)}</title><linearGradient id="s" x2="0" y2="100%"><stop offset="0" stop-color="#bbb" stop-opacity=".1"/><stop offset="1" stop-opacity=".1"/></linearGradient><clipPath id="r"><rect width="${W}" height="20" rx="3" fill="#fff"/></clipPath><g clip-path="url(#r)"><rect width="${lw}" height="20" fill="#334155"/><rect x="${lw}" width="${vw}" height="20" fill="${color}"/><rect width="${W}" height="20" fill="url(#s)"/></g><g fill="#fff" text-anchor="middle" font-family="Verdana,Geneva,DejaVu Sans,sans-serif" font-size="11"><text x="${lw / 2}" y="14">${esc(label)}</text><text x="${lw + vw / 2}" y="14">${esc(value)}</text></g></svg>`;
}
export async function GET(_: Request, { params }: { params: Promise<{ id: string }> }) {
  const id = (await params).id.replace(/\.svg$/, "");
  const b = await badgeData(id);
  const h = { "content-type": "image/svg+xml; charset=utf-8", "x-content-type-options": "nosniff" };
  if (!b) return new Response(svg("ShipSafe", "unavailable", "#64748b"), { status: 404, headers: { ...h, "cache-control": "public, max-age=60" } });
  return new Response(svg("ShipSafe", `${b.score}/100`, scoreColor(b.score)), { headers: { ...h, "cache-control": "public, max-age=300, s-maxage=300" } });
}
