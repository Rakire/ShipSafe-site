import { NextResponse } from "next/server";
import Stripe from "stripe";
import { uid } from "@/lib/auth";
const stripe = new Stripe(process.env.STRIPE_KEY!);
export async function POST() {
  const u = await uid();
  if (!u) return NextResponse.json({ error: "Sign in first." }, { status: 401 });
  const s = await stripe.checkout.sessions.create({ mode: "subscription", line_items: [{ price: process.env.STRIPE_PRICE!, quantity: 1 }], client_reference_id: u,
    success_url: `${process.env.APP_URL}/dashboard`, cancel_url: `${process.env.APP_URL}/dashboard` });
  return NextResponse.json({ url: s.url });
}
