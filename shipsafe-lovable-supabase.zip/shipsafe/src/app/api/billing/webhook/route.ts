import Stripe from "stripe";
import { db } from "@/lib/db";
const stripe = new Stripe(process.env.STRIPE_KEY!);
export async function POST(req: Request) {
  let e: Stripe.Event;
  try { e = stripe.webhooks.constructEvent(await req.text(), req.headers.get("stripe-signature")!, process.env.STRIPE_WH!); }
  catch { return new Response("bad signature", { status: 400 }); }
  if (e.type === "checkout.session.completed") {
    const o = e.data.object as Stripe.Checkout.Session;
    await db.user.update({ where: { id: o.client_reference_id! }, data: { plan: "pro", stripeCustomerId: String(o.customer) } });
  }
  if (e.type === "customer.subscription.deleted") {
    await db.user.updateMany({ where: { stripeCustomerId: String((e.data.object as Stripe.Subscription).customer) }, data: { plan: "free" } });
  }
  return new Response("ok");
}
