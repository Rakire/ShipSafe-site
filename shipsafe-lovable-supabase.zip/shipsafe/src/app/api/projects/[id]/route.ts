import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { uid } from "@/lib/auth";
import { tokenFor, fixGitignorePr } from "@/lib/github";
import { publicHost, verifyDomain, liveChecks } from "@/lib/scan";
const err = (m: string, s = 400) => NextResponse.json({ error: m }, { status: s });
export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params, u = await uid();
  const p = u ? await db.project.findFirst({ where: { id, userId: u } }) : null;
  if (!p) return err("Project not found.", 404);
  const { action, domain } = await req.json();
  try {
    if (action === "domain") {
      const d = String(domain ?? "").toLowerCase().trim();
      if (!(await publicHost(d))) return err("Enter a public domain like example.com.");
      await db.project.update({ where: { id }, data: { domain: d, domainVerified: false, liveCheckedAt: null, liveFindings: [] as any } });
      return NextResponse.json({ ok: true });
    }
    if (action === "verify") {
      if (!p.domain) return err("Add a domain first.");
      const ok = await verifyDomain(p.domain, p.domainToken);
      await db.project.update({ where: { id }, data: { domainVerified: ok } });
      return NextResponse.json({ verified: ok });
    }
    if (action === "live") {
      if (!p.domain || !p.domainVerified) return err("Verify the domain first.", 403);
      if (p.liveCheckedAt && Date.now() - +p.liveCheckedAt < 30_000) return err("Please wait a few seconds before checking again.", 429);
      const f = await liveChecks(p.domain);
      await db.project.update({ where: { id }, data: { liveFindings: f as any, liveCheckedAt: new Date() } });
      return NextResponse.json({ findings: f });
    }
    if (action === "fix") {
      const t = await tokenFor(p.installationId);
      if (!t || !p.installationId) return err("Connect the GitHub App to this project first.");
      return NextResponse.json({ url: await fixGitignorePr(p.owner, p.repo, t) });
    }
  } catch (e: any) { return err(e.message ?? "Something went wrong.", 500); }
  return err("Unknown action.");
}
