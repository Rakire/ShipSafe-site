import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { uid } from "@/lib/auth";
import { parseRepo } from "@/lib/github";
import { describe, scoreOf } from "@/lib/rules";
export async function GET() {
  const u = await uid();
  if (!u) return NextResponse.json({ error: "Sign in first." }, { status: 401 });
  const user = await db.user.findUniqueOrThrow({ where: { id: u } });
  const ps = await db.project.findMany({ where: { userId: u } });
  return NextResponse.json({ plan: user.plan, projects: ps.map(p => {
    const lf = p.domainVerified ? ((p.liveFindings as any[]) ?? []).map(f => describe(f)) : [];
    return { ...p, liveFindings: lf, liveScore: p.domainVerified && p.liveCheckedAt ? scoreOf(lf) : null };
  }) });
}
export async function POST(req: Request) {
  const u = await uid();
  if (!u) return NextResponse.json({ error: "Sign in first." }, { status: 401 });
  const { url, installationId } = await req.json();
  const r = parseRepo(String(url ?? ""));
  if (!r) return NextResponse.json({ error: "Enter a GitHub repository link." }, { status: 400 });
  const p = await db.project.create({ data: { userId: u, owner: r.owner, repo: r.repo, installationId: installationId ? String(installationId) : null } });
  return NextResponse.json({ id: p.id }, { status: 201 });
}
