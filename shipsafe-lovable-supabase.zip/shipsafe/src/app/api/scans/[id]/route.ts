import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { uid } from "@/lib/auth";
import { describe, scoreOf } from "@/lib/rules";
import { langOf } from "@/lib/i18n";
import { ipHashOf } from "@/lib/voter";
import { parseRepo } from "@/lib/github";
export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const s = await db.scan.findUnique({ where: { id } });
  if (!s) return NextResponse.json({ error: "Report not found." }, { status: 404 });
  const u = await uid(), owner = !!u && s.userId === u, ip = ipHashOf(req);
  if (s.isPrivate && !owner && !s.shared) return NextResponse.json({ error: "Report not found." }, { status: 404 });
  const mine = owner || (!s.userId && s.ipHash === ip); // the person who ran the scan, signed in or not
  const full = owner || s.shared || (!s.isPrivate && !!u); // signing in unlocks the full list for public repos
  const lang = langOf(req.headers.get("cookie")?.match(/lang=(\w+)/)?.[1]);
  const votes = mine ? await db.feedback.findMany({ where: { scanId: id, voter: u ?? ip }, select: { findingKey: true, verdict: true } }) : [];
  const vm = new Map(votes.map(v => [v.findingKey, v.verdict]));
  const shape = (f: any) => { const key = `${f.id}|${f.path}|${f.line}`; return { ...describe(f, lang), key, vote: vm.get(key) ?? null }; };
  const all = (s.findings as any[]).map(shape);
  let live = null;
  if (owner) {
    const r = parseRepo(s.repoUrl);
    const p = r ? await db.project.findFirst({ where: { userId: u, owner: { equals: r.owner, mode: "insensitive" }, repo: { equals: r.repo, mode: "insensitive" } } }) : null;
    const lf = p?.domainVerified ? ((p.liveFindings as any[]) ?? []).map(shape) : [];
    live = { hasProject: !!p, domain: p?.domain ?? null, verified: !!p?.domainVerified, checkedAt: p?.liveCheckedAt ?? null, score: p?.domainVerified && p.liveCheckedAt ? scoreOf(lf) : null, findings: lf };
  }
  const base = process.env.APP_URL ?? process.env.NEXTAUTH_URL ?? "";
  const badge = mine && s.status === "done" && (s.shared || !s.isPrivate) ? { img: `${base}/api/badge/${id}`, link: `${base}/b/${id}` } : null;
  return NextResponse.json({ id: s.id, repoUrl: s.repoUrl, status: s.status, error: s.error, score: s.score, stack: s.stack ?? "", owner, mine, shared: s.shared, total: all.length, findings: full ? all : all.slice(0, 5), live, badge });
}
export async function POST(_: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params, u = await uid();
  const s = await db.scan.findUnique({ where: { id } });
  if (!s || !u || s.userId !== u) return NextResponse.json({ error: "Report not found." }, { status: 404 });
  await db.scan.update({ where: { id }, data: { shared: true } });
  return NextResponse.json({ ok: true });
}
