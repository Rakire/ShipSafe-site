import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { ipHashOf } from "@/lib/voter";
import { uid } from "@/lib/auth";
import { parseRepo } from "@/lib/github";
import { queue } from "@/lib/queue";
export async function POST(req: Request) {
  const { url } = await req.json();
  const r = parseRepo(String(url ?? ""));
  if (!r) return NextResponse.json({ error: "Enter a GitHub repository link, like https://github.com/owner/repo" }, { status: 400 });
  const u = await uid();
  const ip = ipHashOf(req);
  const user = u ? await db.user.findUnique({ where: { id: u } }) : null;
  if (user?.plan !== "pro") {
    const since = new Date(Date.now() - 864e5);
    const n = await db.scan.count({ where: user ? { userId: user.id, createdAt: { gte: since } } : { ipHash: ip, createdAt: { gte: since } } });
    const max = Number(process.env.FREE_SCANS_PER_DAY ?? 3);
    if (n >= max) return NextResponse.json({ error: `You’ve used today’s ${max} free scans. Come back tomorrow or upgrade.` }, { status: 402 });
  }
  const s = await db.scan.create({ data: { userId: user?.id, ipHash: ip, repoUrl: `https://github.com/${r.owner}/${r.repo}` } });
  await (await queue()).send("scan", { id: s.id });
  return NextResponse.json({ id: s.id }, { status: 201 });
}
export async function GET() {
  const u = await uid();
  if (!u) return NextResponse.json([]);
  return NextResponse.json(await db.scan.findMany({ where: { userId: u }, orderBy: { createdAt: "desc" }, take: 10, select: { id: true, repoUrl: true, status: true, score: true, createdAt: true } }));
}
