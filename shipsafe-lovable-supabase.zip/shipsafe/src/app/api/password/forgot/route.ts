import { NextResponse } from "next/server";
import { randomBytes } from "crypto";
import { db, sha } from "@/lib/db";
import { norm } from "@/lib/auth";
import { sendMail } from "@/lib/mail";
import { limited, ipOf } from "@/lib/limit";
export async function POST(req: Request) {
  const ok = NextResponse.json({ ok: true }); // same answer whether or not the account exists
  if (limited(`fg:${ipOf(req)}`, 5, 15 * 60e3)) return NextResponse.json({ error: "Too many requests. Try again in a few minutes." }, { status: 429 });
  const { id } = await req.json().catch(() => ({}));
  const k = norm(String(id ?? ""));
  if (!k || !("email" in k)) return ok;
  const u = await db.user.findUnique({ where: { email: k.email } });
  if (!u) return ok;
  const recent = await db.passwordReset.count({ where: { userId: u.id, createdAt: { gt: new Date(Date.now() - 3600e3) } } });
  if (recent >= 3) return ok;
  const token = randomBytes(32).toString("base64url");
  await db.passwordReset.create({ data: { userId: u.id, tokenHash: sha(token), expiresAt: new Date(Date.now() + 3600e3) } });
  const base = process.env.APP_URL ?? process.env.NEXTAUTH_URL ?? "http://localhost:3000";
  await sendMail(k.email, "Reset your ShipSafe password",
    `Use this link to choose a new password. It works once and expires in one hour:\n\n${base}/reset-password?token=${token}\n\nIf you didn’t ask for this, you can ignore this email.`);
  return ok;
}
