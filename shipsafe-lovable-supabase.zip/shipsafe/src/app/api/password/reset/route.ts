import { NextResponse } from "next/server";
import { db, sha } from "@/lib/db";
import { hashPw } from "@/lib/auth";
import { limited, ipOf } from "@/lib/limit";
export async function POST(req: Request) {
  if (limited(`rs:${ipOf(req)}`, 10, 15 * 60e3)) return NextResponse.json({ error: "Too many attempts. Try again in a few minutes." }, { status: 429 });
  const { token, password } = await req.json().catch(() => ({}));
  const pw = String(password ?? "");
  if (pw.length < 10 || pw.length > 128) return NextResponse.json({ error: "Use a password with 10 or more characters." }, { status: 400 });
  const r = token ? await db.passwordReset.findUnique({ where: { tokenHash: sha(String(token)) } }) : null;
  if (!r || r.usedAt || r.expiresAt < new Date()) return NextResponse.json({ error: "bad_link" }, { status: 400 });
  // Claim the token atomically so two simultaneous requests can't both use it.
  const claim = await db.passwordReset.updateMany({ where: { id: r.id, usedAt: null }, data: { usedAt: new Date() } });
  if (claim.count === 0) return NextResponse.json({ error: "bad_link" }, { status: 400 });
  await db.$transaction([
    db.user.update({ where: { id: r.userId }, data: { passwordHash: await hashPw(pw), failed: 0, lockedUntil: null, emailVerified: new Date() } }),
    db.passwordReset.deleteMany({ where: { userId: r.userId, usedAt: null } }),
  ]);
  return NextResponse.json({ ok: true });
}
