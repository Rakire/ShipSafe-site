import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { norm, hashPw } from "@/lib/auth";
import { limited, ipOf } from "@/lib/limit";
export async function POST(req: Request) {
  if (limited(`su:${ipOf(req)}`, 10, 60 * 60e3)) return NextResponse.json({ error: "Too many sign-ups from this network. Try again later." }, { status: 429 });
  const { id, password } = await req.json().catch(() => ({}));
  const k = norm(String(id ?? "")), pw = String(password ?? "");
  if (!k) return NextResponse.json({ error: "Enter a valid email or a 10-digit Indian mobile number." }, { status: 400 });
  if (pw.length < 10 || pw.length > 128) return NextResponse.json({ error: "Use a password with 10 or more characters." }, { status: 400 });
  if (pw.toLowerCase() === String(id).trim().toLowerCase()) return NextResponse.json({ error: "Your password can’t be the same as your email or number." }, { status: 400 });
  try { await db.user.create({ data: { ...k, passwordHash: await hashPw(pw) } }); }
  catch { return NextResponse.json({ error: "An account with these details already exists. Sign in instead." }, { status: 409 }); }
  return NextResponse.json({ ok: true }, { status: 201 });
}
