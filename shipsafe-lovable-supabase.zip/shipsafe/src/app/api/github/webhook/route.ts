import { createHmac, timingSafeEqual } from "crypto";
import { db } from "@/lib/db";
import { queue } from "@/lib/queue";
// Re-scans linked projects whenever someone pushes to them.
export async function POST(req: Request) {
  const raw = await req.text(), sig = req.headers.get("x-hub-signature-256") ?? "";
  const mac = "sha256=" + createHmac("sha256", process.env.GH_WEBHOOK_SECRET!).update(raw).digest("hex");
  if (sig.length !== mac.length || !timingSafeEqual(Buffer.from(sig), Buffer.from(mac))) return new Response("bad signature", { status: 401 });
  if (req.headers.get("x-github-event") === "push") {
    const [owner, repo] = String(JSON.parse(raw).repository?.full_name).split("/");
    const ps = await db.project.findMany({ where: { owner: { equals: owner, mode: "insensitive" }, repo: { equals: repo, mode: "insensitive" } } });
    for (const p of ps) {
      const s = await db.scan.create({ data: { userId: p.userId, repoUrl: `https://github.com/${owner}/${repo}` } });
      await (await queue()).send("scan", { id: s.id });
    }
  }
  return new Response("ok");
}
