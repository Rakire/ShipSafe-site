"use client";
import { useState } from "react";
import { signIn } from "next-auth/react";
import { useT } from "./ui";
import { PasswordField, Strength, safeNext, input, primary } from "./auth-ui";

const OAUTH_ERR: Record<string, string> = {
  OAuthAccountNotLinked: "That email is already used with a different sign-in method. Use the method you signed up with.",
  NoEmail: "Your account didn’t share an email address, so we couldn’t sign you in.",
  Unverified: "Your Google email isn’t verified, so we couldn’t sign you in.",
  AccessDenied: "Sign-in was cancelled or denied.",
};
type Props = { mode: "login" | "signup"; callbackUrl?: string; error?: string; providers: { github: boolean; google: boolean } };

export default function AuthForm({ mode, callbackUrl, error, providers }: Props) {
  const t = useT(), signup = mode === "signup";
  const [id, setId] = useState(""), [pw, setPw] = useState(""), [pw2, setPw2] = useState("");
  const [err, setErr] = useState(error ? OAUTH_ERR[error] ?? "Something went wrong signing you in. Please try again." : ""), [b, setB] = useState(false);
  const social = providers.github || providers.google;

  async function go(e: React.FormEvent) {
    e.preventDefault(); setErr("");
    if (signup && pw !== pw2) { setErr(t("mismatch")); return; }
    setB(true);
    if (signup) {
      const r = await fetch("/api/signup", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ id, password: pw }) });
      if (!r.ok) { setErr((await r.json().catch(() => ({}))).error ?? "Could not create the account."); setB(false); return; }
    }
    const r = await signIn("credentials", { id, password: pw, redirect: false });
    if (r?.error) { setErr("We couldn’t sign you in. Check your details. After five wrong tries, sign-in locks for 15 minutes."); setB(false); }
    else location.href = safeNext(callbackUrl);
  }
  function oauth(p: "github" | "google") { setB(true); signIn(p, { callbackUrl: safeNext(callbackUrl) }); }

  return <main className="mx-auto max-w-sm p-4">
    <h1 className="mb-4 text-2xl font-bold">{signup ? t("signup") : t("signin")}</h1>
    {social && <>
      <div className="flex flex-col gap-2">
        {providers.github && <button type="button" disabled={b} onClick={() => oauth("github")} className="rounded-lg border p-3 font-semibold disabled:opacity-60">{t("with_github")}</button>}
        {providers.google && <button type="button" disabled={b} onClick={() => oauth("google")} className="rounded-lg border p-3 font-semibold disabled:opacity-60">{t("with_google")}</button>}
      </div>
      <div className="my-4 flex items-center gap-3 text-sm text-slate-500"><hr className="flex-1" />{t("or")}<hr className="flex-1" /></div>
    </>}
    <form onSubmit={go} className="flex flex-col gap-3">
      <div className="flex flex-col gap-1">
        <label htmlFor="id" className="font-semibold">{t("id")}</label>
        <input id="id" required autoComplete="username" inputMode="email" value={id} onChange={x => setId(x.target.value)} className={input} />
      </div>
      <PasswordField id="pw" label={t("password")} value={pw} onChange={setPw} autoComplete={signup ? "new-password" : "current-password"} />
      {signup && <>
        <Strength pw={pw} />
        <PasswordField id="pw2" label={t("confirm_password")} value={pw2} onChange={setPw2} autoComplete="new-password" />
      </>}
      {!signup && <a href="/forgot-password" className="self-end text-sm text-indigo-600 dark:text-indigo-400">{t("forgot")}</a>}
      <p role="alert" className="min-h-6 text-sm text-red-600">{err}</p>
      <button disabled={b} className={primary}>{signup ? t("signup") : t("signin")}</button>
    </form>
    <p className="mt-4 text-sm">{signup ? t("have_account") : t("no_account")}{" "}
      <a href={signup ? "/login" : "/signup"} className="font-semibold text-indigo-600 dark:text-indigo-400">{signup ? t("signin") : t("signup")}</a></p>
  </main>;
}
