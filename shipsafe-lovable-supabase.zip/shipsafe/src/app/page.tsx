"use client";
import { useState } from "react";
import { useT } from "./ui";
export default function Home() {
  const t = useT();
  const [u, setU] = useState(""), [e, setE] = useState(""), [b, setB] = useState(false);
  async function go(ev: React.FormEvent) {
    ev.preventDefault(); setB(true); setE("");
    const r = await fetch("/api/scans", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ url: u }) });
    const j = await r.json();
    if (!r.ok) { setE(j.error); setB(false); return; }
    location.href = "/scan/" + j.id;
  }
  return <main className="mx-auto max-w-xl p-4">
    <h1 className="mb-3 text-3xl font-bold leading-tight">{t("title")}</h1>
    <p className="mb-6 text-slate-600 dark:text-slate-300">{t("sub")}</p>
    <form onSubmit={go} className="flex flex-col gap-2 sm:flex-row">
      <input value={u} onChange={x => setU(x.target.value)} required aria-label="GitHub repository link" placeholder="https://github.com/owner/repo" className="flex-1 rounded-lg border bg-transparent p-3" />
      <button disabled={b} className="rounded-lg bg-indigo-600 px-5 py-3 font-semibold text-white disabled:opacity-60">{t("scan")}</button>
    </form>
    <p role="alert" className="mt-2 min-h-6 text-red-600">{e}</p>
    <h2 className="mb-2 mt-8 text-xl font-semibold">{t("chk_h")}</h2>
    <div className="grid gap-3 sm:grid-cols-2">
      <section className="rounded-xl border p-4"><h3 className="font-semibold">{t("chk_code_h")}</h3><p className="mt-1 text-sm">{t("chk_code_p")}</p></section>
      <section className="rounded-xl border border-indigo-600 p-4"><h3 className="font-semibold">{t("chk_live_h")}</h3><p className="mt-1 text-sm">{t("chk_live_p")}</p></section>
    </div>
    <h2 className="mb-2 mt-8 text-xl font-semibold">{t("catch_h")}</h2>
    <ul className="list-disc pl-5 text-sm leading-7">{["c1", "c2", "c3", "c4", "c5", "c6"].map(x => <li key={x}>{t(x)}</li>)}</ul>
  </main>;
}
