import PgBoss from "pg-boss";
import { runScan } from "./lib/scan";
(async () => {
  const boss = new PgBoss(process.env.DATABASE_URL!);
  await boss.start();
  await boss.createQueue("scan");
  await boss.work<{ id: string }>("scan", async ([job]) => { await runScan(job.data.id); });
  console.log("worker ready");
})();
