# ShipSafe

**Focus: Lovable + Supabase apps.** Checks are tuned to the mistakes these apps actually make (open tables, leaked admin keys), and the live-site check looks at the running app, not just the code.

Paste a GitHub repo of an AI-built app (Cursor, Lovable, Bolt, ChatGPT). Get security problems in plain language, with a fix prompt to paste back into your AI tool.

Everything is rule-based, so no Anthropic API key is needed. This code was written without being run. Expect to fix small errors on first run.

## Run on Windows
1. Install Node 20 or newer and PostgreSQL. Create a database called `shipsafe`.
2. `npm install`
3. Copy `.env.example` to `.env` and fill in `DATABASE_URL`, `NEXTAUTH_SECRET` and `IP_SALT`. Add a `GITHUB_TOKEN` (a token with no scopes is enough), or GitHub will limit public scans to 60 requests an hour.
4. `npx prisma db push`
5. Terminal 1: `npm run dev`. Terminal 2: `npm run worker`. Open http://localhost:3000.

## What is in each milestone
1. Home page: paste a public repo, get the top 5 issues, no login.
2. Sign up or sign in with an email or Indian mobile number. Scans are saved in Postgres and run by a background worker. Signing in shows the full list.
3. Dashboard: prove you own a domain (DNS TXT record or a file), then run live checks for missing security headers and exposed `.env` and `.git`.
4. GitHub App: private repos, re-scan on every push, and a fix pull request that adds `.env` to `.gitignore`.
5. Free plan of 3 scans a day, a paid plan through Stripe, shareable reports, and English, Telugu and Hindi.

## GitHub App setup (milestone 4)
Create an app at github.com/settings/apps. Permissions: Contents (read), Metadata (read). For the fix pull request also give Contents (write) and Pull requests (write). Subscribe to the Push event. Webhook URL: `https://your-site/api/github/webhook`, with the secret in `GH_WEBHOOK_SECRET`. Put the app ID in `GH_APP_ID` and the private key in `GH_APP_KEY` (use `\n` for line breaks). Paste the installation ID into the dashboard when adding a project.

## Known limits
- Checks are pattern-based. They miss things and can raise false alarms, for example keys in example docs.
- Dependency checks read the version written in `package.json`, not the lockfile.
- Mobile numbers are not verified by an SMS code, and there is no password reset yet.
- Fix pull requests only handle `.gitignore`. Removing a secret from git history and rotating the key must be done by hand.
- Explanations and fix prompts are in English. Telugu and Hindi cover the interface and issue titles, and need a native speaker’s review.
- Stripe may not be available for new accounts in India. Razorpay is the usual alternative: replace `src/app/api/billing/*`.
- Before charging real customers, add a privacy policy and terms, and get a security review.

## Sign-in options
- Email or Indian mobile + password (argon2, 5-try lockout for 15 min, same-site redirects only)
- Optional GitHub / Google sign-in: set `GITHUB_ID`/`GITHUB_SECRET` and/or `GOOGLE_ID`/`GOOGLE_SECRET`; callback URL is `{NEXTAUTH_URL}/api/auth/callback/<provider>`
- Forgot/reset password by email (one-hour, single-use token). Set `RESEND_API_KEY` + `MAIL_FROM`; in development the link prints to the console
- After pulling these changes run `npm run db:push` (adds `emailVerified`, `PasswordReset`, nullable `passwordHash`)

## Lovable + Supabase checks
Code check (read from the repo; `supabase/` files are always fetched first):
- Tables created in migrations that never get `ENABLE ROW LEVEL SECURITY`. Skipped when any `.sql` file couldn’t be read, so it never guesses.
- Policies that are `true` for everyone, that only check “logged in”, or that trust `user_metadata`.
- `SECURITY DEFINER` functions with no `search_path`, views without `security_invoker`, public storage buckets.
- Service role key (JWT or `sb_secret_…`) written in code, or used in front-end code.
- Edge Functions that use the admin key without `auth.getUser`, and `verify_jwt = false` in `supabase/config.toml`.
- Admin/role flags read from `localStorage`.

## Live-site check (headline feature)
Runs after the owner proves the domain (DNS TXT record, or the file `public/.well-known/shipsafe.txt`, which works on lovable.app addresses). It runs when you press the button and again after every scan of that project, including push re-scans.
- Reads the site’s own JavaScript for admin keys and other secrets (OpenAI, Stripe, AWS, GitHub, private keys).
- Finds the Supabase project and public key in the JavaScript, then asks for **one row per table** with that public key, exactly like any visitor. If a row comes back, the table is open. Only table and column names are kept; row contents are never stored. It never writes data.
- Flags projects where email confirmation is off.
- Safety: only hosted `*.supabase.co` addresses are contacted, redirects stay on the owner’s own hostnames, and the domain’s DNS is re-checked before each run.

## Score badge
After a scan, the report shows a badge snippet (Markdown and HTML). The badge image is `/api/badge/<scan id>` and links to `/b/<scan id>`, a public page with the score only (never the list of problems). It always shows the latest finished scan of that repo. Public repos get a badge right away; private repos need the owner to press Share first.

## Validation: 20 real builders
1. Set `ADMIN_EMAILS` to your sign-in email and open `/admin/validation`.
2. Send the app to Lovable builders (communities, Discord, X). Ask each one to scan their own repo and tap **Useful** or **False alarm** on every finding.
3. The page shows builders scanned, builders who rated, the share of rated findings called useful, and each rule’s rating. Rules with 5+ ratings and 40%+ false alarms are flagged “Tune or remove”.
4. Only ratings from the person who ran the scan count. An anonymous scanner is identified by a salted hash of their IP address, so two people on one network can look like one.

After pulling these changes run `npm run db:push` (adds `Scan.stack`, `Project.liveCheckedAt`, `Feedback`).
